#include <cxxtest/TestSuite.h>

// 定义测试模式，g_is_big_endian修改为非常量 
#define __BUBBLE_TEST__
#include "net_endian.h"

class net_endian_test : public CxxTest::TestSuite
{
public:
    void setUp()
    {
        g_is_big_endian = NET_IS_BIG_ENDIAN; 
    }
    
    void tearDown()
    {
    }
    
    void test_check_endian()
    {
        // 检查大小端检测方法是否有效 
        bool is_big_endian = (0x01020304 == *(int*)"\x01\x02\x03\x04"); 
        bool is_litter_endian = (0x01020304 == *(int*)"\x04\x03\x02\x01"); 
        TS_ASSERT(is_big_endian != is_litter_endian); 
        
        // 测试环境是linux是小端
        TS_ASSERT(!g_is_big_endian); 
    }
    
    void test_reverse_int16()
    {
        TS_ASSERT(net_reverse_int16(0x0102) == 0x0201); 
    }
    
    void test_reverse_int32()
    {
        TS_ASSERT(net_reverse_int32(0x01020304) == 0x04030201); 
    }
    
    void test_reverse_int64()
    {
        TS_ASSERT(net_reverse_int64(0x0102030405060708LL) == 0x0807060504030201LL); 
    }
    
    void test_get_net_int32()
    {
        // 服务器客户端基本都是小端，使用小端字节流传输
        unsigned int org_value = 0x12345678; 
        unsigned int net_value = net_get_net_int32(org_value); 
        if (g_is_big_endian)
        {
            TS_ASSERT(net_value == net_reverse_int32(org_value)); 
        }
        else
        {
            TS_ASSERT(net_value == org_value); 
        }
    }
    
    void test_get_net_int64()
    {
        // 服务器客户端基本都是小端，使用小端字节流传输
        unsigned long long org_value = 0x0102030405060708LL; 
        unsigned long long net_value = net_get_net_int64(org_value); 
        if (g_is_big_endian)
        {
            TS_ASSERT(net_value == net_reverse_int64(org_value)); 
        }
        else
        {
            TS_ASSERT(net_value == org_value); 
        }
    }
};

