#include <cxxtest/TestSuite.h>
#include "test.h"

class SimpleTest : public CxxTest::TestSuite
{
public:
    void testEquality()
    {
        int a = 3; 
        int b = 4; 
        int c = a + b; 
        TS_ASSERT(c == add(a, b)); 
    }
};
