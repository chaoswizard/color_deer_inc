#ifndef __NET_CTRL_H__
#define __NET_CTRL_H__

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <stdlib.h>
#include <signal.h>
#include "net_pack.h"
#include "net_peer.h"

inline int net_send_pack(net_peer * peer, net_pack * pack)
{
    unsigned int pack_len = pack->header.len; 
    
    if (g_is_big_endian)
    {
        pack->header.len = net_reverse_int32(pack->header.len); 
        pack->header.cmd = net_reverse_int32(pack->header.cmd); 
    }
    
    unsigned int write_len = write(peer->conn_fd, pack, pack_len); 
    if (write_len == pack_len)
    {
        return 0; 
    }
    return -1; 
}



#endif // __NET_CTRL_H__

