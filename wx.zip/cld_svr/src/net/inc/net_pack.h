#ifndef __NET_PACKDEF_H__
#define __NET_PACKDEF_H__

#include <string.h>
#include "net_endian.h"

struct net_pack_header
{
    unsigned int len;      // ���ݰ�����
    unsigned int cmd;      // ���ݰ�����
};

#define NET_PACK_SIZE      (1024)
#define NET_PACK_DATA_SIZE (NET_PACK_SIZE - sizeof(net_pack_header))
struct net_pack
{
    union
    {
        net_pack_header  header;                // ���ݰ�ͷ
        char             data[NET_PACK_SIZE];   // ���ݰ���ʽ����
    }; 
};

#define NET_ALIGNMENT_8BIT(len)   ((len & 0x7) == 0 ? len : (len + 8 - (len & 0x7)))
#define NET_ALIGNMENT_4BIT(len)   ((len & 0x3) == 0 ? len : (len + 4 - (len & 0x3)))
#define NET_IS_PACK_FULL(pack, len) ((pack)->header.len + (len) > NET_PACK_SIZE)

inline void net_pack_header_adjust(net_pack * pack)
{
    pack->header.len = net_get_net_int32(pack->header.len); 
    pack->header.cmd = net_get_net_int32(pack->header.cmd); 
}

// ============================
inline void net_pack_init(net_pack * pack, int command)
{
    pack->header.len = sizeof(net_pack_header); 
    pack->header.cmd = command; 
}

inline void * net_pack_alloc_block(net_pack * pack, unsigned int len)
{
    if (!pack) return NULL; 
    
    // ���ֽڶ����������ݳ��ȣ������ռ��Ƿ��㹻 
    len = NET_ALIGNMENT_4BIT(len); 
    if (pack->header.len + len > NET_PACK_SIZE) return NULL; 
    
    void * block = &pack->data[pack->header.len]; 
    pack->header.len += len; 
    return block; 
}

inline int net_pack_put_int32(net_pack * pack, unsigned int value)
{
    unsigned int * data = (unsigned int *)net_pack_alloc_block(pack, sizeof(int)); 
    if (!data) return -1; 
    
    *data = net_get_net_int32(value); 
    return 0; 
}

inline int net_pack_put_int64(net_pack * pack, unsigned long long value)
{
    unsigned long long * data = (unsigned long long *)net_pack_alloc_block(pack, sizeof(long long)); 
    if (!data) return -1; 
    
    *data = net_get_net_int64(value); 
    return 0; 
}

inline int net_pack_put_string(net_pack * pack, char * value, unsigned int len)
{
    char * data = (char *)net_pack_alloc_block(pack, len + 1); 
    if (!data) return -1; 
    
    memcpy(data, value, len); 
    data[len] = '\0'; 
    return 0; 
}

// ================================== 
inline unsigned int net_pack_get_org_offset()
{
    return sizeof(net_pack_header); 
}

inline int net_pack_get_block(net_pack * pack, unsigned int & offset, void ** data, unsigned int data_len)
{
    if (!pack) return -1; 
    
    // ���ֽڶ�����ж�ȡ
    data_len = NET_ALIGNMENT_4BIT(data_len); 

    // ���������ݰ�����
    if (offset + data_len > pack->header.len) return -1; 
    
    *data = &pack->data[offset]; 
    offset += data_len; 
    
    return 0; 
}

inline int net_pack_get_int32(net_pack * pack, unsigned int & offset, unsigned int * data)
{
    unsigned int * value_ptr; 
    int ret = net_pack_get_block(pack, offset, (void**)&value_ptr, sizeof(int)); 
    if (ret < 0) return -1; 
    
    *data = net_get_net_int32(*value_ptr); 
    return 0; 
}

inline int net_pack_get_int64(net_pack * pack, unsigned int & offset, unsigned long long * data)
{
    unsigned long long * value_ptr; 
    int ret = net_pack_get_block(pack, offset, (void**)&value_ptr, sizeof(long long)); 
    if (ret < 0) return -1; 
    
    *data = net_get_net_int64(*value_ptr); 
    return 0; 
}

inline int net_pack_get_string(net_pack * pack, unsigned int & offset, char ** data, unsigned int data_len)
{
    return net_pack_get_block(pack, offset, (void**)data, data_len); 
}

#include <stdio.h>
inline char cld_hex2char(char value)
{
    unsigned char fix_value = value & 0xf; 
    if (fix_value < 10) return fix_value + '0'; 
    else return fix_value + 'A' - 10; 
}
inline void cld_strcat(char * buf, const char * token, int & len_remain)
{
    if (!buf || !token) return; 
    if (len_remain <= 0) return; 

    int len = strlen(token); 
    strncat(buf, token, len_remain); 
    len_remain -= len; 
}
inline char * net_pack_parse_format(net_pack * pack)
{
    const int buf_len = 1024 * 4; 
    char line[128]; 
    static char show_str[buf_len]; 
    show_str[0] = '\0'; 

    // ������Ϣ
    int str_len_remain = buf_len; 
    net_pack_header * header = &pack->header; 
    sprintf(line, "Pack length: %d  Command: %d\n", header->len, header->cmd); 
    cld_strcat(show_str, line, str_len_remain); 

    // �����ӡ����
    const int byte_per_line = 16; 
    int line_num = header->len / byte_per_line; 
    if (header->len % byte_per_line != 0) line_num += 1; 

    for (int i = 0; i < line_num; i++)
    {
        int j; 
        line[0] = '\0'; 
        char token_str[32]; 
        int line_len_remain = sizeof(line); 

        // �к�
        sprintf(token_str, "%00d: ", i + 1); 
        cld_strcat(line, token_str, line_len_remain); 
        for (j = 0; j < byte_per_line; j++)
        {
            // ����ֽ���Ϣ
            int idx = i * byte_per_line + j; 
            unsigned char ch = pack->data[idx]; 
            sprintf(token_str, "%c%c ", cld_hex2char(ch >> 4), cld_hex2char(ch & 0xf)); 
            cld_strcat(line, token_str, line_len_remain); 
        }

        // ��ӡ�ַ���Ϣ
        cld_strcat(line, "     ", line_len_remain); 
        for (j = 0; j < byte_per_line; j++)
        {
            int idx = i * byte_per_line + j; 
            unsigned char ch = pack->data[idx]; 
            if (ch < ' ') ch = '.';   // ���ɼ��ַ��滻Ϊ"."��ӡ����
            sprintf(token_str, "%c ", ch); 
            cld_strcat(line, token_str, line_len_remain); 
        }
        cld_strcat(line, " \n", line_len_remain); 
        cld_strcat(show_str, line, str_len_remain); 
    }
    return show_str; 
}

#endif // __NET_PACKDEF_H__
