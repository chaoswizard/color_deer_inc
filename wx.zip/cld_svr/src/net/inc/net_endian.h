#ifndef __NET_ENDIAN_H__
#define __NET_ENDIAN_H__

#define NET_IS_BIG_ENDIAN (0x01020304 == *(int*)"\x01\x02\x03\x04")

#ifdef __BUBBLE_TEST__
bool g_is_big_endian = NET_IS_BIG_ENDIAN; 
#else
const bool g_is_big_endian = NET_IS_BIG_ENDIAN; 
#endif

inline unsigned short net_reverse_int16(unsigned short value)
{
    unsigned short ret_value = 0; 
    unsigned char * data1 = (unsigned char *)&value; 
    unsigned char * data2 = (unsigned char *)&ret_value; 
    data2[0] = data1[1]; 
    data2[1] = data1[0]; 
    return ret_value; 
}

inline unsigned int net_reverse_int32(unsigned int value)
{
    unsigned int ret_value = 0; 
    unsigned char * data1 = (unsigned char *)&value; 
    unsigned char * data2 = (unsigned char *)&ret_value; 
    data2[0] = data1[3]; 
    data2[1] = data1[2]; 
    data2[2] = data1[1]; 
    data2[3] = data1[0]; 
    return ret_value; 
}

inline unsigned long long net_reverse_int64(unsigned long long value)
{
    unsigned long long ret_value = 0; 
    unsigned char * data1 = (unsigned char *)&value; 
    unsigned char * data2 = (unsigned char *)&ret_value; 
    data2[0] = data1[7]; 
    data2[1] = data1[6]; 
    data2[2] = data1[5]; 
    data2[3] = data1[4]; 
    data2[4] = data1[3]; 
    data2[5] = data1[2]; 
    data2[6] = data1[1]; 
    data2[7] = data1[0]; 
    return ret_value; 
}

// ���ǵ���Ŀ��״���������Ϳͻ��˻�������С�ˡ����紫��ʹ��С���ֽ���
inline unsigned int net_get_net_int32(unsigned int value)
{
    if (!g_is_big_endian) return value; 
    else return net_reverse_int32(value); 
}

inline unsigned long long net_get_net_int64(unsigned long long value)
{
    if (!g_is_big_endian) return value; 
    else return net_reverse_int32(value); 
}

#endif // __NET_ENDIAN_H__

