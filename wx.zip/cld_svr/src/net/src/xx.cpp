int a()
{
    return 0; 
}

