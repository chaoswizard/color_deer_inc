#include <stdlib.h>
#include <stdio.h>
#include "net_session.h"
#include <sys/time.h>
#include <string.h>
#include "cldLogger.h"


#define CNS_MAX_SIZE	1024
//64
#define CNS_LEAST_OFFSET		(CNS_MAX_SIZE/16)

#if 0
struct cldSession
{
	long long uid;
	int fd;
	struct cldSession *next;
};

class cldSessHash
{
	int cap;
	int count;
	struct cldSession *sh;
	
	cldSessHash();
	~cldSessHash();

public:
	int addSess(long long id, int fd);
	int getFdSess(long long id);
//	int removeFdSess(long long id);
};

#else
struct cldSession
{
	int fd;
	int date;
	int ver;
	int unused;
	long long uid;
};

class cldSessHash
{
	int cap;
	int count;
	struct cldSession *sh;
	int replaceLeastSess(long long id, int fd);
public:
	cldSessHash();
	~cldSessHash();

	int addSess(long long id, int fd);
	int getFdSess(long long id);
}; 
#endif

static cldSessHash *csh = NULL;

#if 0
cldSessHash::cldSessHash()
{
	cap = CNS_MAX_SIZE;
	count = 0;
	sh = (struct cldSession*)malloc(cap*sizeof(struct cldSession));
	bzero(sh, cap*sizeof(struct cldSession));
}

cldSessHash::~cldSessHash()
{
	struct cldSession *pCur, *pNext;

	for (int i = 0; i < cap; i++)
	{
		pCur = sh[i].next;
		pNext = pCur;
		while (pNext != NULL)
		{
			pNext = pCur->next;
			free(pCur);
			pCur = pNext;
		}
	}
	free(sh);
}

int addSess(long long id, int fd)
{
	int key = id%cap;
	struct cldSession *pCur = &sh[key];
	struct cldSession *pNext = pCur->next;

	while (pNext != NULL)
	{
		if (pCur->uid == id)
			break;
		pCur = pNext;
		pNext = pNext->next;
	}

	if (pCur->uid == id)
	{
		if (pCur->fd != fd)
		{
			int tmp = pCur->fd;
			pCur->fd = fd;

			return tmp;
		}
		else
			return fd;
	}

	struct cldSession *pAdd = (struct cldSession*)malloc(sizeof(struct cldSession));
	pAdd->uid = id;
	pAdd->fd = fd;
	pAdd->next = NULL;

	pCur->next = pAdd;

	count ++;

	return fd;
}
	
int cldSessHash::getFdSess(long long id)
{
	int key = id%cap;
	struct cldSession *pCur = &sh[key];
	
	while ((pCur != NULL) && (pCur->uid != id))
	{
		pCur = pCur->next;
	}

	if (pCur == NULL)
		return -1;

	return pCur->fd;
}

#else
cldSessHash::cldSessHash()
{
	cap = CNS_MAX_SIZE;
	count = 0;
	sh = (struct cldSession*)malloc(CNS_MAX_SIZE*sizeof(struct cldSession));
	bzero(sh, cap*sizeof(struct cldSession));
	
	printf("cld session hash init ok!\n");
}

cldSessHash::~cldSessHash()
{
	free(sh);

	printf("cld session hash descructor!\n");
}

int cldSessHash::replaceLeastSess(long long id, int fd)
{
	cLog::shareLog()->logger(Mod_NET, Lvl_Warning, "replaceLeastSess(), id:%lld, fd:%d", id, fd);
	printf("cldSessHash::replaceLeastSess()\n");

	int key = id%cap;
	
	int least = sh[key].date;
	int idx = 0;
	for (int i = 0; i < CNS_LEAST_OFFSET; i++)
	{
		if (least > sh[key+i].date)
		{
			least = sh[key+i].date;
			idx = i;
		}
	}
	
	int tmp = sh[key+idx].fd;

	sh[key+idx].uid = id;
	sh[key+idx].fd = fd;

	
	struct timeval tv;
	gettimeofday(&tv, NULL);

	sh[key+idx].date = tv.tv_sec;

	return tmp;
}
	
int cldSessHash::addSess(long long id, int sid)
{
	
	int key = id%cap;
	int i;
	for (i = 0; i < cap; i++)
	{
		if (sh[key].uid == 0 || sh[key].uid == id)
			break;

		key = (key+1)%cap;
	}	

	if (i == cap)
		return replaceLeastSess(id, sid);

	int tmp = sh[key].fd;

	sh[key].uid = id;
	sh[key].fd = sid;	
		
	struct timeval tv;
	gettimeofday(&tv, NULL);

	sh[key].date = tv.tv_sec;

//	printf("add session ok, id:%lld, fd:%d\n", id, sh[key].fd);

	return tmp;
}

int cldSessHash::getFdSess(long long id)
{
	int key = id%cap;
	int i;
	for (i = 0; i < cap; i++)
	{
		if (sh[key].uid == 0 || sh[key].uid == id)
			break;
		key = (key+1)%cap;
	}

	if (i == cap)
		return 0;
	
	return sh[key].fd;
}
#endif

int cldSess_init(void)
{
	if (csh == NULL)
		csh = new cldSessHash();
	
	return 1;
}

int cldSess_add_sess(long long id, int fd)
{
	if (csh == NULL)
		return 0;
	return csh->addSess(id, fd);
}


int cldSess_get_fd(long long id)
{
	if (csh == NULL)
		return 0;
	return csh->getFdSess(id);
}

