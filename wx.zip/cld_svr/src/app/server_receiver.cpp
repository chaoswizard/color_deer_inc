#include <unistd.h>
#include <stdlib.h>
#include <poll.h>
#include <list>
#include "server.h"

#include "net_ctrl.h"
#include "net_cmddef.h"
#include "svrMsgQueue.h"
#include "net_session.h"
#include "cldLogger.h"

extern fd_set g_fd_set; 
//extern std::list<int> g_conn_fd_list; 
net_pack g_recv_pack; 
net_pack g_send_pack; 

void server_close_socket(int conn_fd)
{
    printf("close  conn_fd %d \n", conn_fd);
    // ��������������ٹرվ��������select�ȷ��־���쳣������������
	FD_CLR(conn_fd, &g_fd_set);
	close(conn_fd);
}

void server_handle_net_pack(int conn_fd, net_pack * pack)
{
	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "fd: %d, recv pack:%s", conn_fd, net_pack_parse_format(pack));
    net_peer peer; 
    peer.conn_fd = conn_fd; 
    unsigned int pack_offset = net_pack_get_org_offset(); 
    switch (pack->header.cmd)
    {
	case NET_CMD_ERR:
		break;
	case NET_CMD_NONE:
		break;
        case NET_CMD_CONNECT:
        {
            	net_pack_connect * conn_pack; 
            	int ret = net_pack_get_block(pack, pack_offset, (void**)&conn_pack, sizeof(net_pack_connect)); 
		if (ret < 0)
		{
			cLog::shareLog()->logger(Mod_NET, Lvl_Error, " connect get block failed");
		 	return; 
		}
		ret = cldSess_add_sess(conn_pack->user_id, conn_fd);
		if (ret == 0)
		{
			cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "socket sess add, id:%lld, fd:%d", conn_pack->user_id, conn_fd);
			printf("add new session, fd:%d\n", conn_fd);
		}
		else if (ret != conn_fd)
		{
			//reloggin, close last socket connect
			cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "id:%lld reconnect, add fd:%d, close fd:%d", conn_pack->user_id, conn_fd, ret);
			printf("close fd:%d, new:%d\n", ret, conn_fd);
			server_close_socket(ret);
		}

		smq_push_msg(sizeof(net_pack_connect), NET_CMD_CONNECT, conn_pack);
            // ��Ӧ��¼ 
       //     	net_pack_init(&g_send_pack, 0); 
       //     	net_send_pack(&peer, &g_send_pack); 
            	break; 
        }
	case NET_CMD_SYNC:
	{
		net_pack_user *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_user));
		if (ret < 0)
			return;
		smq_push_msg(sizeof(net_pack_user), NET_CMD_SYNC, pkt);
	
		break;
	}
	case NET_CMD_UPDATE_SCORE:
	{
		int temp = pack_offset;
		net_pack_update_score *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_update_score));
		if (ret < 0)
			return;
		int cnt = pkt->num;
		pack_offset = temp;
		ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_update_score)+cnt*sizeof(int));

		smq_push_msg(sizeof(net_pack_update_score)+cnt*sizeof(int), NET_CMD_UPDATE_SCORE, pkt);

		break;
	}
	case NET_CMD_FETCH_SCORE:
	{
		net_pack_request_fetch_score *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_request_fetch_score));
		if (ret < 0)
			return;

		smq_push_msg(sizeof(net_pack_request_fetch_score), NET_CMD_FETCH_SCORE, pkt);
		break;
	}
	case NET_CMD_FRIEND_MAX_LEVEL: 
	{
		net_pack_request_friend_max_level *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_request_friend_max_level));
		if (ret < 0)
			return;
		smq_push_msg(sizeof(net_pack_request_friend_max_level), NET_CMD_FRIEND_MAX_LEVEL, pkt);
	
		break;
	}	
	case NET_CMD_FRIENDSHIP:
	{
		int tempLen = pack_offset;

		net_pack_friend_list *msg;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&msg, sizeof(net_pack_friend_list));
		if (ret < 0)
			return;
		int cnt = msg->friend_num;
	//	printf("net,fs, id:%lld, num:%d\n", msg->user_id, msg->friend_num);
		pack_offset = tempLen;
		ret = net_pack_get_block(pack, pack_offset, (void**)&msg, sizeof(net_pack_friend_list)+cnt*sizeof(long long));
		if (ret < 0)
			return;
	//	long long *fList = (long long*)((char*)msg+sizeof(net_pack_friendship));
	//	for (int i = 0; i < cnt; i++)
	//		printf("fl:%d, id:%lld\n", i, fList[i]);
		char *buf = (char*)malloc(sizeof(net_pack_friendship)+cnt*sizeof(long long));
		memcpy(buf, msg, sizeof(net_pack_friendship)+cnt*sizeof(long long));
		
		smq_push_msg((sizeof(net_pack_friendship)+cnt*sizeof(long long)), NET_CMD_FRIENDSHIP, buf);
		free(buf);
		break;
	}
	case NET_CMD_LOAD_FRIENDSHIP:
	{
		net_pack_load_friend *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_load_friend));
		if (ret < 0)
			return;

		smq_push_msg(sizeof(net_pack_load_friend), NET_CMD_LOAD_FRIENDSHIP, pkt);
		break;
	}
	case NET_CMD_FRIEND_RANK:
	{
		net_pack_request_rank *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_request_rank));
		if (ret < 0)
			return;
		smq_push_msg(sizeof(net_pack_request_rank), NET_CMD_FRIEND_RANK, pkt);
		 
		break;
	}
	case NET_CMD_ALL_RANK:
	{
		net_pack_request_rank *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_request_rank));
		if (ret < 0)
			return ;
		smq_push_msg(sizeof(net_pack_request_rank), NET_CMD_ALL_RANK, pkt);
		
		break;
	}
	case NET_CMD_QUERY_HEART_MSG:
	{
		net_pack_query_heart_msg *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_query_heart_msg));
		if (ret < 0)
			return;
		smq_push_msg(sizeof(net_pack_query_heart_msg), NET_CMD_QUERY_HEART_MSG, pkt);
		break;
	}
	case NET_CMD_REQUEST_HEART:
	{
		net_pack_request_heart *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_request_heart));
		if (ret < 0)
			return;
		smq_push_msg(sizeof(net_pack_request_heart), NET_CMD_REQUEST_HEART, pkt);
		break;
	}
	case NET_CMD_GIFT_HEART:
	{
		net_pack_heart_gift *pkt;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&pkt, sizeof(net_pack_heart_gift));
		if (ret < 0)
			return ;
		smq_push_msg(sizeof(net_pack_heart_gift), NET_CMD_GIFT_HEART, pkt);
		
		break;
	}
	case NET_CMD_CONFIRM_HEART:
	{
		net_pack_heart_confirm *msg_pack;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&msg_pack, sizeof(net_pack_heart_confirm));
		if (ret < 0)
		{
			cLog::shareLog()->logger(Mod_NET, Lvl_Error, "confirm heart get block failed");
			return ;
		}

		smq_push_msg(sizeof(net_pack_heart_confirm), NET_CMD_CONFIRM_HEART, msg_pack);
		break;
	}
	case NET_CMD_UPDATE_STATUS:
	{
		net_pack_request_user_update_status *msg_pack;
		unsigned int temp = pack_offset;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&msg_pack, sizeof(net_pack_request_user_update_status));
		if (ret < 0)
		{
			cLog::shareLog()->logger(Mod_NET, Lvl_Error, "update status get block failed");
			return ;
		}

		int cnt = msg_pack->num;
		pack_offset = temp;
		ret = net_pack_get_block(pack, pack_offset, (void**)&msg_pack, sizeof(net_pack_request_user_update_status)+cnt*sizeof(user_status_info));
		if (ret < 0)
			return;
		smq_push_msg(sizeof(net_pack_request_user_update_status)+cnt*sizeof(user_status_info), NET_CMD_UPDATE_STATUS, msg_pack);
		break;
	}
	case NET_CMD_QUERY_STATUS:
	{
		net_pack_request_user_query_status *msg_pack;
		unsigned int temp = pack_offset;
		int ret = net_pack_get_block(pack, pack_offset, (void**)&msg_pack, sizeof(net_pack_request_user_query_status));
		if (ret < 0)
		{
			cLog::shareLog()->logger(Mod_NET, Lvl_Error, "query status failed!");
			return ;
		}
		int cnt = msg_pack->num;
		pack_offset = temp;
		ret = net_pack_get_block(pack, pack_offset, (void**)&msg_pack, sizeof(net_pack_request_user_query_status)+cnt*sizeof(int));
		if (ret < 0)
			return ;
		
		smq_push_msg(sizeof(net_pack_request_user_query_status)+cnt*sizeof(int), NET_CMD_QUERY_STATUS, msg_pack);
		break;
	}
        case NET_CMD_MESSAGE:
        {
            net_pack_message * msg_pack; 
            int ret = net_pack_get_block(pack, pack_offset, (void**)&msg_pack, sizeof(net_pack_message)); 
            if (ret < 0)
		 return; 
            printf("[%d] receive message: %s\n", conn_fd, msg_pack->message); 
		smq_push_msg(sizeof(net_pack_message), NET_CMD_MESSAGE, msg_pack);
        	break;
	}
        default :
            break; 
    }
}

void server_send_net_pack(long long id, int cmd, void *buf, int len)
{
        net_pack_init(&g_send_pack, cmd); 
        net_pack *msg_pack = (net_pack*)net_pack_alloc_block(&g_send_pack, len);
        
        if (! msg_pack)
	{
		printf("snd pack alloc failed!\n"); 
		return ; 
        }

	memcpy(msg_pack, buf, len); 
       
	net_peer peer;
	bzero(&peer, sizeof(net_peer));
	peer.conn_fd = cldSess_get_fd(id); 
       // net_adjust_pack_message(msg_pack); 
//       	printf("send pack fd:%d\n", peer.conn_fd); 
        (void)net_send_pack(&peer, &g_send_pack); 
}	


int net_receive_data(int conn_fd, char * data_buf, int data_len)
{
    // BEGIN ���select����
    // todo: ���޸�ֻ�ǽ��й�ܣ����⻹�������λ���
    fd_set temp_set; 
    FD_ZERO(&temp_set); 
    FD_SET(conn_fd, &temp_set); 
    struct timeval tv; 
    tv.tv_sec = 0; 
    tv.tv_usec = 50; 
    int nselect = select(conn_fd+1, &temp_set, NULL, NULL, &tv); 
    if (nselect <= 0)
    {
        // ���select�пɶ����ݣ���������û��
        cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "conn fd[%d] select error.", conn_fd);
        return -1; 
    }
    // END 

    int repeat_num = 0; 
    while (1)
    {
        int ret = read(conn_fd, data_buf, data_len);
        if (ret == -1)
        {
            if (errno == EINTR)
            {
                repeat_num++; 
                if (repeat_num > 10) 
                {
                    perror("too many intr"); 
                    return -1; 
                }
                continue;
            }
            else
            {   
                perror("call to read");
                return -1; 
            }
        } 
        else if (ret == 0)
        {
		cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "fd:%d disconnect", conn_fd);
            printf("the peer[%d] disconnect.\n", conn_fd);
            //g_conn_fd_list.remove(conn_fd); 
            FD_CLR(conn_fd, &g_fd_set); 
            return -1;
        }
        break; 
    }

    return 0; 
}

void server_receive_net_pack(int conn_fd)
{
    // �Ƚ��հ�ͷ����ȷ�����ݰ�����
    char * data_buf = (char*)&g_recv_pack; 
    int header_len = sizeof(net_pack_header); 
    int ret = net_receive_data(conn_fd, data_buf, header_len); 
    if (ret < 0)
    {
        return; 
    }

    // ����������
    net_pack_header * header = (net_pack_header*)data_buf; 
    int remain_len = header->len - header_len; 
    if (remain_len > 0)
    {
        // ������ݰ����а��壬����հ���
        ret = net_receive_data(conn_fd, data_buf + header_len, remain_len); 
        if (ret < 0)
        {
            return; 
        }
    }
    
    // ��ǰ���ݰ��Ѿ�������ϣ�ÿ��ֻ����һ�����ݰ������������ݰ�
    server_handle_net_pack(conn_fd, &g_recv_pack); 
}

/*
void * thread_server_receiver(void * data)
{
    int nready; 
    struct timeval tv = {0, 0};    // ���Ϸ��� 
    while(1)
    {
        if (g_conn_fd_list.size() == 0)
        {
            // ��ת 
            usleep(SEVER_IDLE_SLEEP_TIME); 
            continue; 
        }

        nready = select(1024, &g_fd_set, NULL, NULL, NULL); 
        if (nready == -1)
        {
            perror("select error"); 
            exit(1); 
        }
        if (nready == 0)
        {
            // ��ת 
            usleep(SEVER_IDLE_SLEEP_TIME); 
            continue; 
        }
        
        std::list<int> remove_list; 
        std::list<int>::iterator iter; 
        for (iter = g_conn_fd_list.begin(); iter != g_conn_fd_list.end(); iter++)
        {
            int conn_fd = *iter; 
            if (!FD_ISSET(conn_fd, &g_fd_set)) continue; 
            server_receive_net_pack(conn_fd); 
            
            // ���ͨѶ�Ͽ��ˣ���ѭ����ɾ���þ��������������� 
            if (!FD_ISSET(conn_fd, &g_fd_set))
            {
                remove_list.push_back(conn_fd); 
            }
        }
        
        // ��ȫ�����Ͽ��˵�����
        for (iter = remove_list.begin(); iter != remove_list.end(); iter++)
        {
            g_conn_fd_list.remove(*iter); 
        }
    }
    
    return NULL; 
}
*/
