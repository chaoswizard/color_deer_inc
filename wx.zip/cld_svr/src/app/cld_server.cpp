#include "cld_server.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int cld_server::start(const char *ip, int port)
{
    assert(m_listen_sock == -1);
    assert(ip);
    assert(port > 0);
    
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) 
        return -1;
        
    int on = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &on, (socklen_t)sizeof(on)) == -1)
    {
        close(sock);
        return -1;
    }
    
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = ip ? inet_addr(ip) : INADDR_ANY;
    
    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) == -1 || ::listen(sock, 20) == -1)
    {
        close(sock);
        return -1;
    }
    
    if (m_poll->add(sock, this) == -1)
    {
        close(sock);
        return -1;
    } 
    
    m_poll->set(sock, cld_read) ;
    assert(m_poll->update(sock)== 0);
    
    m_listen_sock = sock;
    return 0;
}

int cld_server::stop()
{
    assert(m_listen_sock != -1);
    assert(m_poll->del(m_listen_sock) == 0);
    close(m_listen_sock);
    m_listen_sock = -1;
    return 0;
}

// accept new connection
void cld_server::on_event(cld_poll *poll, int fd, short event)
{
    int sock = accept(fd, NULL, NULL);
    if (sock >= 0)
    {
        int on = 1; 
        
        setsockopt (sock, SOL_TCP, TCP_NODELAY, &on, sizeof (on));
        cld_conn *conn = new cld_conn(poll);
        
        if (conn->accept(sock, NULL) == -1)
        {
            delete conn;
            ::close(sock);
            return;
        }
        m_listener->on_accept(poll, conn);
    }
}


