#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>

#include "cldHashIndex.h"
#include "cldUserCacheIndex.h"
#include "cldMsgQueue.h"
#include "cldUserCacheBlock.h"
#include "server.h"
#include "hashid.h"
#include "svrMsgQueue.h"
#include "msg_handler.h"
#include "net_session.h"
#include "cldDbAdaptor.h"
#include "cldLogger.h"
#include "dbMsgHandler.h"
#include "cldAllUserHash.h"

#include "cld_server.h"
#include "cld_poll.h"

#define MAX_LEVEL_COUNT		5

class server_mgr : public cld_listener
{
public:
    server_mgr() : m_server(&m_poll), m_conn_nr(0)
    {
        pthread_mutex_init(&m_lock, NULL);
        m_server.set_listener(this);
    }
    
    int start(const char *ip, int port)
    {
        assert(m_poll.init() >= 0);

        return m_server.start(ip, port);
    }

    cld_poll *get_poll()
    {
        return &m_poll;
    }
    
    virtual void on_accept(cld_poll *poll, cld_conn *conn)
    {
        ++m_conn_nr;
        m_client_pool.insert(std::map<cld_conn *, uint64_t,>::value_type(conn, m_conn_nr));
    }
private:
    cld_poll m_poll;
    cld_server m_server;
    std::map<cld_conn *,  uint64_t> m_client_pool;
    pthread_mutex_t m_lock;
    uint64_t m_conn_nr;
}


int main(int argc, char *argv[])
{
    // ignore pipe break signal, avoid exit when peer illegal disconnect
    signal(SIGPIPE,SIG_IGN);
	printf("cldeer bubble server start..........\n");
	int ret;	///////////////////////////////////////////////


	cLog::shareLog()->init("LOG-SVR");
	
	cLog::shareLog()->logger(Mod_SYS, Lvl_Critical, "cldeer bubble server start now! wzh");	

	ret = hashid_init();
	cLog::shareLog()->logger(Mod_SYS, Lvl_Critical, "hashid init ret:%d", ret);

	ret = smq_init();
	cLog::shareLog()->logger(Mod_SYS, Lvl_Critical, "smq init ret:%d", ret);

	ret = cldSess_init();
	cLog::shareLog()->logger(Mod_SYS, Lvl_Critical, "session init ret:%d", ret);

	ret = db_connect();
	cLog::shareLog()->logger(Mod_SYS, Lvl_Critical, "db init ret:%d", ret);
	if (ret <= 0)
	{
		exit(1);
	}
	/////////////////////////////////////////////////////
	long long *list = (long long*)malloc(16*sizeof(long long));
	long long *flist = (long long*)malloc(10*sizeof(long long));

	unsigned int count = 0;
	int cnt;
	int offset = 0;
	while ((cnt = db_get_userlist(list, offset, 16)))
	{
		for (int i = 0; i < cnt; i++)
		{
			//add to user list
			userTab::shareUT()->push_id(list[i]);

		if (count < 1024*64)
		{
			struct cdUCI *pUci = insert_hashid_fd(list[i]);
			if (pUci == NULL)
			{
				cLog::shareLog()->logger(Mod_SYS, Lvl_Error, "insert id:%lld failed", list[i]);
			}
			else
			{
				count ++;
				cLog::shareLog()->logger(Mod_SYS, Lvl_Backup, "id:%lld added", list[i]);
				//add score list
				int score;
				for (int j = 1; j <= MAX_LEVEL_COUNT; j++)
				{
					if ((score = db_get_score_level(list[i], j)) >= 0)
					{
						cLog::shareLog()->logger(Mod_SYS, Lvl_Backup, "level %d score %d added", j, score);
//						printf("level:%d, score:%d", i, score);
						((cdUCB*)(pUci->pUCB))->updateScore(j, score);
					}
				}


				{//add friendship
				int fcnt;
				int foff = 0;
				while ((fcnt = db_get_friendship(list[i], flist, foff, 10)))
				{
					foff += 10;
					add_friend_hashid_fd(list[i], flist, fcnt);
				}
				}
			}
		}
		}
		offset += 16;
	}
/*
	offset = 0;		
	while ((cnt = db_get_userlist(list, offset, 16)))
	{
		for (int i = 0; i < cnt; i++)
		{
			
			{
				int count;
				int foff = 0;
				while ((count = db_get_friendship(list[i], flist, foff, 10)))
				{
					foff += 10;
					
					add_friend_hashid_fd(list[i], flist, count);
				}
			}
		}
		offset += 16;
	}
*/
	free(list);
	free(flist);

	cLog::shareLog()->logger(Mod_SYS, Lvl_Critical, "cache architecture set up finish!");

/*
	//////////////////////////////////////////////////////
	FILE *fp;
	char *line = NULL;
	size_t len = 0;
	ssize_t read;
	
	fp = fopen("li", "r");
	if (fp != NULL)
	{
		char dbuf[16] = {0};
		while ((read = getline(&line, &len, fp)) != -1)
		{
			memcpy(dbuf, line, 10);
			long long id = atoll(dbuf);
			struct cdUCI *pUci = get_hashid(id);
			if (pUci == NULL)
				printf("E:%lld\n", id);
		}
	}
	else
		printf("li open failed!\n");

	if (line)
		free(line);

	fclose(fp);
*/
/*


	fp = fopen("li", "r");
	if (fp != NULL)
	{
		int idx = 0;
		
		char ibuf[16] = {0};
		while ((read = getline(&line, &len, fp)) != -1)
		{
			memcpy(ibuf, line, 10);
			long long uid = atoll(ibuf);
			bzero(ibuf, 16);
			memcpy(ibuf, &line[11], 4);
			int score = atoi(ibuf);			
			insert_hashid(uid);
			
			struct cdUCI *pUci = get_hashid(uid);	
			if (pUci != NULL)
				((cdUCB*)pUci->pUCB)->updateScore(1, score);	
			else
				printf("!");	
	
			//printf("%d ", idx);
			idx ++;
		}
	}
	else
	{
		printf("!!! file test open failed!!!\n");	
	}

	if (line)
		free(line);
	fclose(fp);
	
	line = NULL;
	////////////////////// bcf confige read ////////////
//	printf("-----------bcf config start!!!!---------");
	fp = fopen("bcf", "r");
	if (fp != NULL)
	{
		char cn[] = "\n";
		int wf;
		wf = open("out", O_CREAT | O_RDWR);
		if (wf < 0)
			printf("out open failed\n");

		int idx = 0;
		long long *flist = (long long*)malloc(100*sizeof(long long));
		char sbuf[16] = {0};
		while ((read = getline(&line, &len, fp)) != -1)
		{
		//	printf("%s", line);
//			printf("--%d--", idx++);
			memcpy(sbuf, line, 10);
			long long id = atoll(sbuf);
			write(wf, sbuf, 11);
			bzero(sbuf, 16);
			memcpy(sbuf, &line[11], 2);
			write(wf, sbuf, 3);
			int cnt = atoi(sbuf);
			if (cnt <= 0)
			{
				write(wf, cn, 1);
				continue;
			}

			for (int i = 0; i < cnt; i++)
			{
				memcpy(sbuf, &line[14+11*i], 10);
				flist[i] = atoll(sbuf);
	//			printf("%lld,", flist[i]);
				write(wf, sbuf, 11);
			}
		//	printf("\n");
			write(wf, cn, 1);	
			
			add_friend_hashid(id, flist, cnt);
		
		}	
		close(wf);
		free(flist);
	}
	else
		printf("bcf file open failed!\n");

	if (line)
		free(line);
	fclose(fp);

	printf("--------config finished!!-------\n");

/////////////////////////////////////////////////
	line = NULL;

	fp = fopen("li", "r");
	if (fp != NULL)
	{
		int wf;
		wf = open("result", O_CREAT | O_RDWR);
		if (wf < 0)
			printf("open result failed\n");

		int idx = 0;
		while ((read = getline(&line, &len, fp)) != -1)
		{
			long long uid = atoll(line);
			
		//	insert_hashid(uid);
			int ret = 0;
			struct cdUCI *pUci = get_hashid(uid);	
			if (pUci != NULL)
				ret = ((cdUCB*)pUci->pUCB)->getScoreOfLevel(1);//, 10000-idx*10);	
			else
				printf("!");
			char rbuf[32] = {0};
			sprintf(rbuf, "%lld:%d\n", uid, ret);
			write(wf, rbuf, 20);	
//			printf("%d ", idx++);
		}
		close(wf);
	}
	else
	{
		printf("reopen li failed\n");
	}
	if (line)
		free(line);
	fclose(fp);
*/
////////////////////////////////////////////////////
			

	
////////////////////////////////////////////////////////////
    server_mgr srv_mgr;
    
    pthread_t thread_id; 

    // start server
    if (srv_mgr.start(NULL, 3344) == -1)
    {
        printf("start=-1\n");
        return 1;
    }
    
    ret = pthread_create(&thread_id, NULL, thread_net_listener, (void *)&srv_mgr); 
    if (ret != 0)
    {
	cLog::shareLog()->logger(Mod_SYS, Lvl_Error, "start accept thread failed!");
        perror("start accept thread error");
//	cld_logger_close();
 
        exit(1); 
    }
	ret = pthread_create(&thread_id, NULL, thread_db_msg_main, (void *)&srv_mgr);
	if (ret != 0)
	{
		cLog::shareLog()->logger(Mod_SYS, Lvl_Error, "start db msg handler thread failed!");
		perror("db msg handler thread error");
//		cld_logger_close();
	
		exit(1);
	}


/////////////////////////////////////////////////////
	printf("server main thread start !\n");
	cLog::shareLog()->logger(Mod_SYS, Lvl_Critical, "main thread start!!");

/////////////////////////////////////////////////////
        cld_poll  *poll = srv_mgr.get_poll();
        poll->run();
/////////////////////////////////////////////////////////////////
	
	db_close();

	cLog::shareLog()->logger(Mod_SYS, Lvl_Critical, "server terminal!");
//	cld_logger_close();

	printf("server terminal!!!\n");	
	return 0;	
}


static void * thread_net_listener(void * data)
{
    server_mgr *svr_mgr = (server_mgr *)data;
    
    while (1)
    {
    	struct cldMsg *msg = smq_pop_msg();
    	if (msg != NULL)
    	{
    		cbs_msg_handler(msg);
    		if (msg->data)
    			free(msg->data);
    	}
    	else
    	{
    		usleep(10);
    	}
    }
}
 
