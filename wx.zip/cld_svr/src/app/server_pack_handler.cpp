#include <unistd.h>
#include <stdlib.h>
#include "server.h"
#include "net_pack.h"


bool server_is_recv_new_pack(net_pack * pack)
{
    return false; 
}

void server_handle_data_pack(net_pack * pack)
{
    return; 
}

void * thread_server_pack_handler(void * data)
{
    net_pack data_pack; 
    while (1)
    {
        bool is_recv_new_pack = server_is_recv_new_pack(&data_pack); 
        if (!is_recv_new_pack)
        {
            // 没有数据包，空转 
            usleep(SEVER_IDLE_SLEEP_TIME); 
            continue; 
        }
        
        // 处理新接收到的数据包 
        server_handle_data_pack(&data_pack); 
    }; 
    return NULL; 
}

