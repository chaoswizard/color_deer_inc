#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>

#include "msg_handler.h"
#include "net_cmddef.h"
#include "hashid.h"
#include "cldUserCacheBlock.h"
#include "server.h"
#include "cldDbAdaptor.h"
#include "cldLogger.h"

#define CLD_ONCE_HEART_MSG_SIZE		10
#define CLD_MSG_TIME_OFFSET		(3*24*3600)

int cbs_msg_handler(struct cldMsg *msg)
{
	if (msg == NULL)
		return 0;
	switch (msg->type)
	{
	case NET_CMD_ERR:
		break;
	case NET_CMD_NONE:
		break;
	case NET_CMD_CONNECT:
	{
		net_pack_connect *pkt = (net_pack_connect*)msg->data;
		long long id = pkt->user_id;
//		long long id = *(long long*)msg->data;	
		printf("connect, id:%lld\n", id);
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_CONNECT id %lld", id);
		int ret = insert_hashid(id);
		if (ret < 0)
		{
			cLog::shareLog()->logger(Mod_MQ, Lvl_Error, "insert id:%lld failed", id);
		}
		net_pack_ack_connect ack = {ret};
		server_send_net_pack(id, NET_CMD_CONNECT, &ack, sizeof(net_pack_connect));
/*		struct levelStatus lvl;
		ret = get_level_status_hashid(id, &lvl);
		if (ret > 0)
			server_send_net_pack(id, NET_CMD_LEVEL_STATUS, &lvl, sizeof(struct levelStatus));		
*/		break;
	}
	case NET_CMD_SYNC: 
	{
		net_pack_user *pkt = (net_pack_user*)msg->data;
//		printf("NCS, id:%lld\n", pkt->user_id);
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_SYNC id %lld", pkt->user_id);
		update_hashid(pkt->user_id);
		net_pack_err ack = {0};
		server_send_net_pack(pkt->user_id, NET_CMD_SYNC, &ack, sizeof(net_pack_err));
		break;
	}
	case NET_CMD_UPDATE_SCORE:
	{
		net_pack_update_score *pkt = (net_pack_update_score*)msg->data;
//		printf("update score, id%lld, level:%d, score:%d\n", pkt->user_id, pkt->level_num, pkt->score); 
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_UPDATE_SCORE id %lld start_levle:%d, num:%d", pkt->user_id, pkt->start_level, pkt->num);
		int *slist = (int*)((char*)pkt+sizeof(net_pack_update_score));
		if (pkt->num > 0)
		{
		int ret = update_score_list_hashid(pkt->user_id, pkt->start_level, slist, pkt->num);
		if (ret < 0)
			cLog::shareLog()->logger(Mod_MQ, Lvl_Error, "cbs_msg_handler(), CMD_SCORE, id:%lld not found", pkt->user_id);
		}
		update_paidlevel_hashid(pkt->user_id, pkt->last_paid_level);
		net_pack_err ack = {0};
		server_send_net_pack(pkt->user_id, NET_CMD_UPDATE_SCORE, &ack, sizeof(net_pack_err));
		break;
	}
	case NET_CMD_FETCH_SCORE:
	{
		net_pack_request_fetch_score *pkt = (net_pack_request_fetch_score*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_FETCH_SCORE id %lld", pkt->user_id);
		struct cdUCI *pUci = get_hashid(pkt->user_id);
		if (pUci == NULL)
		{
			return 1;
		}
		int maxLevel = ((cdUCB*)(pUci->pUCB))->getMaxLevel();
		int cnt = ((maxLevel-pkt->start_level+1)<pkt->num)?maxLevel-pkt->start_level+1:pkt->num;
		net_pack_ack_fetch_score *ack = (net_pack_ack_fetch_score*)malloc(sizeof(net_pack_ack_fetch_score)+cnt*sizeof(int));
		ack->start_level = pkt->start_level;
		ack->num = cnt;
		ack->is_end = (maxLevel <= (pkt->start_level+pkt->num))?1:0;
		ack->last_paid_level = get_paidlevel_hashid(pkt->user_id);

		int *pList = (int*)((char*)ack+sizeof(net_pack_ack_fetch_score));
		for (int i = 0; i < cnt; i++)
		{
			pList[i] = ((cdUCB*)(pUci->pUCB))->getScoreOfLevel(pkt->start_level+i);
//			printf("l:%d, score:%d\n", ack->start_level+i, pList[i]);	
		}

		server_send_net_pack(pkt->user_id, NET_CMD_FETCH_SCORE, ack, sizeof(net_pack_ack_fetch_score)+cnt*sizeof(int));
		
		free(ack);
		break;
	}
	case NET_CMD_FRIEND_MAX_LEVEL:
	{
		net_pack_request_friend_max_level *pkt = (net_pack_request_friend_max_level*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_MAX_LEVLE id %lld", pkt->user_id);
//		printf("NCFML, id:%lld, start:%d, end:%d\n", pkt->user_id, pkt->start, pkt->end);
		int getCnt = pkt->num;
		net_pack_ack_friend_max_level *msg = (net_pack_ack_friend_max_level*)malloc(sizeof(net_pack_ack_friend_max_level)+getCnt*sizeof(struct max_level_info));
		msg->start = pkt->start;
		struct levelInfo *pList = (struct levelInfo*)((char*)msg+sizeof(net_pack_ack_friend_max_level));
		int cnt = get_max_level_friend_hashid(pkt->user_id, pList, pkt->start, getCnt);
		msg->num = cnt;
		msg->is_end = (getCnt-cnt)?1:0;

		server_send_net_pack(pkt->user_id, NET_CMD_FRIEND_MAX_LEVEL, msg, sizeof(net_pack_ack_friend_max_level)+cnt*sizeof(struct max_level_info));
		free(msg);
		break;
	}
	case NET_CMD_FRIENDSHIP:
	{
		net_pack_friend_list *pkt = (net_pack_friend_list*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_FRIENDSHIP id %lld count:%d", pkt->user_id, pkt->friend_num);
		
		long long *fList = (long long*)((char*)pkt+sizeof(net_pack_friend_list));
		int ret = add_friend_hashid(pkt->user_id, fList, pkt->friend_num);
//		printf("fs ret:%d\n", ret);
		for (int i = 0; i < pkt->friend_num; i++)
		{
			printf("f:%d, id:%lld\n", i, fList[i]);
			cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "; %lld; ", fList[i]);	
		}
#if 0
		net_pack_err ack = {0};
		server_send_net_pack(pkt->user_id, NET_CMD_FRIENDSHIP, &ack, sizeof(net_pack_err));
		
#else		
		int count = ret?ret:0;
		net_pack_ack_friend_list *ack = (net_pack_ack_friend_list*)malloc(sizeof(net_pack_ack_friend_list)+count*sizeof(long long));
		ack->start = 1;
		ack->num = count;
		ack->is_end = 1;
		long long *al = (long long*)((char*)ack+sizeof(net_pack_ack_friend_list));
		for (int i = 0; i < count; i++)
			al[i] = fList[i];
		server_send_net_pack(pkt->user_id, NET_CMD_FRIENDSHIP, ack, sizeof(net_pack_ack_friend_list)+count*sizeof(long long));
//		printf("vf,start:%d, count:%d, isEnd:%d\n", ack->start, ack->count, ack->isEnd);
//		for (int i = 0; i < count; i++)
//			printf("vf, %d: %lld\n", i, al[i]);
		free(ack);
#endif
		break;
	}
	case NET_CMD_LOAD_FRIENDSHIP:
	{
		net_pack_load_friend *pkt = (net_pack_load_friend*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_FRIEND_LOAD_FRIENDSHIP id:%lld", pkt->user_id);
//		long long *fList = NULL;
		break;
	}
	case NET_CMD_FRIEND_RANK:
	{
		net_pack_request_rank *pkt = (net_pack_request_rank*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_FRIEND_RANK id %lld", pkt->user_id);
//		printf("friend rank, id:%lld, level:%d, start:%d, end:%d\n", pkt->user_id, pkt->level_num, pkt->start, pkt->end);
		long long *fList = NULL;
		int *sList = NULL;
		int cnt = get_sort_frdlist_hashid(pkt->user_id, &fList, &sList, pkt->level_num);
		int count;
		if (cnt > 0 || cnt >= pkt->start)
		{
			count = ((cnt-pkt->start)<pkt->num)?(cnt-pkt->start+1):(pkt->num);
			
		}
		else
		{
			count = 0;
		}
		net_pack_ack_rank *msg = (net_pack_ack_rank*)malloc(sizeof(net_pack_ack_rank)+count*sizeof(rank_info));
		msg->start = pkt->start;
		msg->num = count;
		msg->is_end = (cnt>(pkt->start+count))?0:1;
		if (count)
		{
			rank_info *pInfo = (rank_info*)((char*)msg+sizeof(net_pack_ack_rank));
			int start = pkt->start-1;
			for (int i = 0; i < count; i++)
			{
				pInfo->friend_id = fList[start+i];
				pInfo->score = sList[start+i];
				pInfo++;
			}
				
		}
		server_send_net_pack(pkt->user_id, NET_CMD_FRIEND_RANK, msg, sizeof(net_pack_ack_rank)+count*sizeof(rank_info));

		if (msg)
			free(msg);
		if (fList)
			free(fList);
		if (sList)
			free(sList);
		break;
	}
	case NET_CMD_ALL_RANK:
	{
		net_pack_request_rank *pkt = (net_pack_request_rank*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_ALL_RANK id %lld", pkt->user_id);
//		printf("NCAR, id:%lld, level:%d, start:%d, end:%d\n", pkt->user_id, pkt->level_num, pkt->start, pkt->end);
		int rCnt = pkt->num;
		net_pack_ack_rank *msg = (net_pack_ack_rank*)malloc(sizeof(net_pack_ack_rank)+rCnt*sizeof(struct rank_info));
		struct dbRankInfo *rList = (struct dbRankInfo*)((char*)msg+sizeof(net_pack_ack_rank));
		
		int oCnt = db_get_all_rank_level(rList, pkt->level_num, pkt->start-1, rCnt);
		msg->start = pkt->start;
		msg->num = oCnt;
		msg->is_end = (oCnt < rCnt)?1:0;
		server_send_net_pack(pkt->user_id, NET_CMD_ALL_RANK, msg, sizeof(net_pack_ack_rank)+oCnt*sizeof(struct rank_info));
		free(msg);
		break;
	}
	case NET_CMD_QUERY_HEART_MSG:
	{
		net_pack_query_heart_msg *pkt = (net_pack_query_heart_msg*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_QUERY_HEART_MSG id %lld", pkt->user_id);
//		printf("query msg, id:%lld\n", pkt->user_id);
		struct cdUCI *pUci = get_hashid(pkt->user_id);
		int cnt = uci_get_msg_count(pUci);
//		printf("msg cnt:%d\n", cnt);
		if (cnt <= 0)
		{
			net_pack_heart_msg_head ml = {0, 1};
			server_send_net_pack(pkt->user_id, NET_CMD_QUERY_HEART_MSG, &ml, sizeof(net_pack_heart_msg_head));
			return 0;
		}
		net_pack_heart_msg_head * ml = (net_pack_heart_msg_head*)malloc(sizeof(net_pack_heart_msg_head)+CLD_ONCE_HEART_MSG_SIZE*sizeof(heart_msg_info));
		struct timeval tv;
		gettimeofday(&tv, NULL);
		long curTime = tv.tv_sec;

		struct hrtMsg *hm = NULL;
		int offset = 0;
		do
		{
			heart_msg_info *p = (heart_msg_info*)((char*)ml+sizeof(net_pack_heart_msg_head));
			int i = 0;
			do
			{
//				hm = pop_hrtmsg_hashid(pkt->user_id);
				hm = read_hrtmsg_hashid(pkt->user_id);
				offset++;
				if ((hm->timestamp+CLD_MSG_TIME_OFFSET) > curTime)
				{
					p->type = hm->type;
					p->friend_id = hm->uid;
					p->time_retain = hm->timestamp+CLD_MSG_TIME_OFFSET-curTime;
					p++;
					i++;
//					pop_hrtmsg_hashid(pkt->user_id);
				}
				else
				{
					pop_hrtmsg_hashid(pkt->user_id);
				}
			} while ((offset < cnt)&&(i < CLD_ONCE_HEART_MSG_SIZE));
			ml->num = i;
			ml->is_end = (cnt-offset)?0:1;

//			printf("send id:%lld query msg, count:%d\n", pkt->user_id, ml->count);
			server_send_net_pack(pkt->user_id, NET_CMD_QUERY_HEART_MSG, ml, sizeof(net_pack_heart_msg_head)+ml->num*sizeof(heart_msg_info));
		} while (offset < cnt);
		
		free(ml);
//		printf("query msg eixt\n");
		break;
	}
	case NET_CMD_REQUEST_HEART:
	{
		net_pack_request_heart *pkt = (net_pack_request_heart*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_REQUEST_HEART id %lld", pkt->user_id);
//		printf("request heart, id:%lld\n", pkt->user_id);
		push_reqHrtmsg_hashid(pkt->user_id);

		net_pack_err ack = {0};
		server_send_net_pack(pkt->user_id, NET_CMD_REQUEST_HEART, &ack, sizeof(net_pack_err));
		break;
	}
	case NET_CMD_GIFT_HEART:
	{
		net_pack_heart_gift *pkt = (net_pack_heart_gift*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_GIFT_HEART id %lld gift frd %lld", pkt->user_id, pkt->friend_id);
//		printf("gift heart, id:%lld, friend:%lld\n", pkt->user_id, pkt->friend_id);
		push_giftHrtmsg_hashid(pkt->user_id, pkt->friend_id);
		net_pack_err ack = {0};
		server_send_net_pack(pkt->user_id, NET_CMD_GIFT_HEART, &ack, sizeof(net_pack_err));
		break;
	}
	case NET_CMD_CONFIRM_HEART:
	{
		net_pack_heart_confirm *pkt = (net_pack_heart_confirm*)msg->data;
		cLog::shareLog()->logger(Mod_MQ, Lvl_Debug, "<<CMD_CONFIRM_HEART id %lld frd %lld", pkt->user_id, pkt->friend_id);
//		printf("confirm heart, id:%lld, friend:%lld\n", pkt->user_id, pkt->friend_id);
		push_cnfHrtmsg_hashid(pkt->user_id, pkt->friend_id);
		net_pack_err ack = {0};
		server_send_net_pack(pkt->user_id, NET_CMD_CONFIRM_HEART, &ack, sizeof(net_pack_err));
		break;
	}
	case NET_CMD_UPDATE_STATUS:
	{
		net_pack_request_user_update_status *pkt = (net_pack_request_user_update_status*)msg->data;
		int cnt = pkt->num;
		user_status_info *info = (user_status_info*)((char*)pkt+sizeof(net_pack_request_user_update_status));
		for (int i = 0; i < cnt; i++)
		{
			if (info[i].type == USER_STATUS_LAST_PAID_LEVEL)
			{
				update_paidlevel_hashid(pkt->user_id, info[i].value);
			}
		}
		net_pack_err ack = {0};
		server_send_net_pack(pkt->user_id, NET_CMD_UPDATE_STATUS, &ack, sizeof(net_pack_err));
		break;
	}
	case NET_CMD_QUERY_STATUS:
	{
		net_pack_request_user_query_status *pkt = (net_pack_request_user_query_status*)msg->data;
		int cnt = pkt->num;
		net_pack_ack_user_query_status *ack = (net_pack_ack_user_query_status*)malloc(sizeof(net_pack_ack_user_query_status)+cnt*sizeof(user_status_info));
		user_status_info *info = (user_status_info*)((char*)ack+sizeof(net_pack_ack_user_query_status));
		int *type = (int*)((char*)pkt+sizeof(net_pack_request_user_query_status));
		for (int i = 0; i < cnt; i++)
		{
			if (type[i] == USER_STATUS_LAST_PAID_LEVEL)
			{
				info[i].type = USER_STATUS_LAST_PAID_LEVEL;
				info[i].value = get_paidlevel_hashid(pkt->user_id);
			}
		}
		ack->num = cnt;

		server_send_net_pack(pkt->user_id, NET_CMD_QUERY_STATUS, &ack, sizeof(net_pack_ack_user_query_status)+cnt*sizeof(user_status_info));
		free(ack);
		break;
	}
	case NET_CMD_MESSAGE:
	{
		net_pack_message *pkt = (net_pack_message*)msg->data;
		printf("NCM, len:%d, message: ", pkt->str_len);
	//	for (int i = 0; i < pkt->str_len; i++)
	//		printf("%c", pkt->message[i]);
//		dumpMsgTest_hashid(1644629692);
		break;
	}
	default:
		break;
	}
	return 1;
}
