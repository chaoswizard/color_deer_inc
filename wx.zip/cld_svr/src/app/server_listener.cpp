#include "cld_server.h"
#include <unistd.h>
#include <stdlib.h>
#include <netinet/tcp.h>
#include "server.h"
#include <list>
//#include "net_pack.h"

fd_set g_fd_set; 
std::list<int> g_conn_fd_list; 

int server_net_init(int & listen_fd)
{
    struct sockaddr_in sin;
    bzero(&sin, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons(3344);

    listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd == -1)
    {
        perror("call to socket");
        return -1;
    }
    
    // �󶨷���˿� 
    int ret = bind(listen_fd, (struct sockaddr *)&sin, sizeof(sin));
    if (ret == -1)
    {
        perror("call to bind");
        return -1;
    }
    
    // ��ʼ���� 
    ret = ::listen(listen_fd, 20);
    if (ret == -1)
    {
        perror("call to listen");
        return -1;
    }
    
    return 0; 
}

void server_accept_new_peer(int conn_fd, sockaddr_in * pin)
{
    // �����ӵĿͻ���
    char ip_str[32]; 
    printf("new peer[%d] ip: %s, port %d:\n",
        conn_fd, 
        inet_ntop(AF_INET, &pin->sin_addr, ip_str, sizeof(ip_str)),
        ntohs(pin->sin_port));
        
    // �������ݰ����Ϸ��� 
    int on = 1; 
    setsockopt (conn_fd, SOL_TCP, TCP_NODELAY, &on, sizeof (on));
        
    // ���ӵ�fd�б���
    FD_SET(conn_fd, &g_fd_set); 
    g_conn_fd_list.push_back(conn_fd); 

    return; 
}

void handle_receive(fd_set * new_select_fd)
{
    std::list<int> remove_list; 
    std::list<int>::iterator iter; 
    for (iter = g_conn_fd_list.begin(); iter != g_conn_fd_list.end(); iter++)
    {
        int conn_fd = *iter; 
        if (!FD_ISSET(conn_fd, new_select_fd)) continue; 
        if (!FD_ISSET(conn_fd, &g_fd_set))
        {
            // �����Ѿ��������Ͽ�
            remove_list.push_back(conn_fd); 
            continue; 
        }

        // ҵ��������
        server_receive_net_pack(conn_fd); 
        
        // ���ͨѶ�Ͽ��ˣ���ѭ����ɾ���þ��������������� 
        if (!FD_ISSET(conn_fd, new_select_fd))
        {
            remove_list.push_back(conn_fd); 
        }
    }
    
    // ��ȫ�����Ͽ��˵�����
    for (iter = remove_list.begin(); iter != remove_list.end(); iter++)
    {
        g_conn_fd_list.remove(*iter); 
    }
}

void * thread_server_listener(void * data)
{
    // �����ʼ�� 
    int listen_fd; 
    int ret = server_net_init(listen_fd); 
    if (ret != 0) exit(1); 
    cld_server
    FD_ZERO(&g_fd_set); 
    FD_SET(listen_fd, &g_fd_set); 
    
    printf("Accepting connections...\n");

    int nselect; 
    int conn_fd; 
    fd_set temp_fd_set; 
    struct sockaddr_in pin;
    socklen_t address_size = sizeof(pin);
    while(1)
    {
        memcpy(&temp_fd_set, &g_fd_set, sizeof(temp_fd_set)); 
        nselect = select(1024, &temp_fd_set, NULL, NULL, NULL); 
        if (nselect == -1)
        {
            perror("select error"); 
            exit(1); 
        }
        if (nselect == 0)
        {
            // ��ת 
            usleep(SEVER_IDLE_SLEEP_TIME); 
            continue; 
        }

        if (FD_ISSET(listen_fd, &temp_fd_set))
        {
            // ���µ�����
            conn_fd = accept(listen_fd, (struct sockaddr *)&pin, &address_size);
            server_accept_new_peer(conn_fd, &pin); 

            nselect--; 
            if (nselect == 0)
            {
                continue; 
            }
        }

        // ���µ����ݰ�
        handle_receive(&temp_fd_set); 
    }
    
    return NULL; 
}

