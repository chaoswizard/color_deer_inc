#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "cldDbQueue.h"
#include "cldDbAdaptor.h"
#include "dbMsgHandler.h"

void db_msg_handler(struct dbMsg *msg)
{
	switch (msg->type)
	{
	case DB_ReqhrtInsert:
	case DB_GifthrtInsert:
	case DB_CnfhrtInsert:
	{
		struct dbHrtmsg dm;
		dm.type = msg->type;
		dm.time = msg->timestamp;
		dm.fid = msg->fid;

		db_insert_hrtmsg(msg->id, &dm);
		break;
	}
	case DB_ScoreInsert:
	{
		int level = msg->sdata.level;
		int score = msg->sdata.score;
		db_insert_score(msg->id, level, score);
		break;
	}
	case DB_ScoreUpdate:
	{
		int level = msg->sdata.level;
		int score = msg->sdata.score;
		db_update_score(msg->id, level, score);
		break;
	}
	case DB_FrdInsert:
	{
		long long fid = msg->fid;
		db_insert_friendship(msg->id, fid);
		break;
	}
	case DB_FrdDelete:
	{
		long long fid = msg->fid;
		db_delete_friendship(msg->id, fid);
		break;
	}
	case DB_Paidlevel:
	{
		int level = msg->sdata.level;
		db_insert_paidlevel(msg->id, level);
		break;
	}
	default:
		break;

	}
}


void* thread_db_msg_main(void *arg)
{

	printf("db_msg_main() start!!");
	
	db_queue_init();
	
	while (1)
	{

		struct dbMsg *msg = db_queue_pop();
		if (msg != NULL)
			db_msg_handler(msg);
		usleep(10000);
	}
}


