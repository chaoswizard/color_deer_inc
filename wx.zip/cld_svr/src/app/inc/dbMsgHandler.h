#ifndef _CLD_DB_MSG_HANDLER_H_
#define _CLD_DB_MSG_HANDLER_H_


void* thread_db_msg_main(void *arg);

#endif
