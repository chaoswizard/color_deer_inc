#ifndef _CLD_NET_SESSION_H_
#define _CLD_NET_SESSION_H_

/*
#if 0
struct cldSession
{
	long long uid;
	int fd;
	struct cldSession *next;
};

class cldSessHash
{
	int cap;
	int count;
	struct cldSession *sh;
	
	cldSessHash();
	~cldSessHash();

public:
	int addSess(long long id, int fd);
	int getFdSess(long long id);
//	int removeFdSess(long long id);
};
#else
struct cldSession
{
	int fd;
	unsigned int date;
	long long uid;
};

class cldSessHash
{
	int cap;
	int count;
	struct cldSession *sh;
public:
	cldSessHash();
	~cldSessHash();

	int addOneSess(long long id, int fd);
	int getFdSess(long long id);
}; 
#endif
*/

int cldSess_init(void);
int cldSess_add_sess(long long id, int fd);
int cldSess_get_fd(long long id);

#endif

