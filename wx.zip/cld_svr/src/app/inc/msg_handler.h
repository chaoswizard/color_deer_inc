#ifndef _CLD_MSG_HANDLER_H_
#define _CLD_MSG_HANDLER_H_
#include "cldMsgQueue.h"

int cbs_msg_handler(struct cldMsg *msg);

#endif

