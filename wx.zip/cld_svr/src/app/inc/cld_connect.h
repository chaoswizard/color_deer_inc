#ifndef _CLD_CONN_H
#define _CLD_CONN_H

#include <assert.h>
#include <stdlib.h>
#include <inttypes.h>
#include "cld_poll.h"
#include <string>


class cld_conn: public cld_fd
{
    enum conn_status { none, connecting, connected };
public:
    cld_conn(cld_poll *poll):m_poll(poll), m_sock(-1),m_status(none)
    { assert(poll); }

    virtual void on_event(cld_poll *poll, int fd, short event);
    int accept(int fd, struct sockaddr_in *addr);
    int  close();
private:
    void handle_read();
    void handle_write();
    void handle_error();
    int m_sock;
    cld_poll *m_poll;
    conn_status m_status;
};

#endif

