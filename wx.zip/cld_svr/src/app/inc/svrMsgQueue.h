#ifndef _SVR_MSG_QUEUE_H_
#define _SVR_MSG_QUEUE_H_
#include "cldMsgQueue.h"

int smq_init(void);
int smq_push_msg(int len, int type, void* data);
struct cldMsg* smq_pop_msg(void);


#endif

