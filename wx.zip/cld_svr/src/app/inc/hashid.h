#ifndef _CLD_HASH_ID_H_
#define _CLD_HASH_ID_H_
#include "cldUserCacheIndex.h"

struct levelInfo
{
	long long friend_id;
	int max_level;
};

struct levelStatus
{
	int max_level;
	int lack_level;
};


int hashid_init(void);
int insert_hashid(long long id);
struct cdUCI* insert_hashid_fd(long long id);
struct cdUCI* get_hashid(long long id); 
struct cdUCI* update_hashid(long long id);
int get_level_status_hashid(long long id, struct levelStatus *pSt);
int get_sort_frdlist_hashid(long long id, long long **fList, int **scoreList, int level);

int update_score_hashid(long long id, int level, int score);
int update_score_list_hashid(long long id, int startLvl, int *scoreList, int count);

int update_paidlevel_hashid(long long id, int level);
int get_paidlevel_hashid(long long id);

int get_max_level_friend_hashid(long long id, struct levelInfo *list, int offset, int count);
int add_friend_hashid(long long id, long long *frdList, int cnt);
int add_friend_hashid_fd(long long id, long long *frdList, int cnt);
int remove_friend_hashid(long long id, long long fid);

int push_reqHrtmsg_hashid(long long id);
int push_giftHrtmsg_hashid(long long id, long long fid);
int push_cnfHrtmsg_hashid(long long id, long long fid);
struct hrtMsg* pop_hrtmsg_hashid(long long id);
struct hrtMsg* read_hrtmsg_hashid(long long id);

////////////////

void dumpMsgTest_hashid(long long id);

#endif

