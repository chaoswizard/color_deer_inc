#ifndef _CLD_SERVER_H
#define _CLD_SERVER_H

#include "cld_poll.h"
#include <vector>
#include <deque>
#include <inttypes.h>
#include <signal.h>

class cld_listener
{
public:
    virtual void on_accept(cld_poll *poll, cld_conn *conn) = 0;
    virtual cld_listener() {}
};

class cld_server: public cld_fd
{
public:
    cld_server(cld_poll *poll): m_poll(poll),m_listen_sock(-1), m_listener(NULL)
    {
        assert(poll); 
    }
    int start(const char *ip, int port);
    int stop();
    int set_listener(cld_listener *listener) { m_listener = listener; return 0;}
    virtual void on_event(cld_poll *poll, int fd, short event);
private:
    cld_poll *m_poll;
    int m_listen_sock;
    cld_listener *m_listener;
}


#endif
