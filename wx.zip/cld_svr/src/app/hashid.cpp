#include <stdlib.h>
#include <stdio.h>
#include <map>
#include <vector>
#include <algorithm>
#include <sys/time.h>

#include "cldHashIndex.h"
#include "cldUserCacheIndex.h"
#include "cldUserCacheBlock.h"
#include "hashid.h"
#include "cldLogger.h"
#include "cldDbAdaptor.h"
#include "cldDbQueue.h"
#include "cldAllUserHash.h"


#define CLD_VALIDITY_OFFSET (3*24*3600)
 
using namespace std;

static cldHash *g_node_ht = NULL;

int hashid_init(void)
{
	if (g_node_ht == NULL)
	{
		g_node_ht = new cldHash();
		if (g_node_ht == NULL)
			return 0;
	}

	return 1;
}

void store_db_hashid(struct cdUCI *pUci)
{
	if (pUci == NULL || pUci->mBox == NULL)
		return;

	printf("# store_db_hashid\n");
	int count = pUci->mBox->chm_get_cnt_msg();
	if (count <= 0)
		return;

	struct timeval tv;
	gettimeofday(&tv, NULL);
	long curTime = tv.tv_sec;

	struct dbMsg dm;
	dm.id = pUci->uid;

	struct hrtMsg *msg;
	for (int i = 0; i < count; i++)
	{
		msg = pUci->mBox->chm_pop_msg();
		if (msg->timestamp == 0 || msg->timestamp+CLD_VALIDITY_OFFSET > curTime)
			continue;

		dm.type = dbOptType(msg->type);
		dm.timestamp = msg->timestamp;
		dm.fid = msg->uid;
			
		db_queue_push(&dm);
	}

}

void restore_db_hashid(long long id)
{
	struct dbHrtmsg *hl = (struct dbHrtmsg*)malloc(32*sizeof(struct dbHrtmsg));

	int cnt = db_get_hrtmsg_list(id, hl);
	printf("restore db, id:%lld, cnt:%d\n", id, cnt);
	struct dbHrtmsg *p = hl;

	struct timeval tv;
	gettimeofday(&tv, NULL);
	
	struct cdUCI *pUci = get_hashid(id);	
	struct hrtMsg msg;//= {p->type, 0, id};
	for (int i = 0; i < cnt; i++)
	{
		if (p->time+ CLD_VALIDITY_OFFSET> tv.tv_sec)
		{
			msg.type = hMsgType(p->type);
			msg.timestamp = p->time;
			msg.uid = p->fid;

			uci_push_msg(pUci, &msg);
		}
	}

	if (cnt)
	{
		printf("delete hrtmsg\n");
		db_delete_hrtmsg(id);
	}

	free(hl);
}


int insert_hashid(long long id)
{
	if (g_node_ht == NULL)
		return -1;

#if (CHI_HASHTAB_METHOD == 1)
	struct cdUCI *pUci = g_node_ht->chi_insert_id(id);
	if (pUci->uid != id)
	{
		store_db_hashid(pUci);
		uci_free(pUci);
	}

	int ret = userTab::shareUT()->push_id(id);
	printf("insert id, ret:%d\n", ret);
	return ret;
#elif (CHI_HASHTAB_METHOD == 0)
	struct cdUCI *pUci = g_node_ht->chi_insert_id(id);
	if (pUci->uid != id)
	{
		store_db_hashid(pUci);
		uci_free(pUci);
	}

	return 1;
/*
	int ret = g_node_ht->chi_insert_id(id);
	if (ret == 0)
		goto ih_exit;
	if (ret == -1)
	{
		printf("inset hashid, store db\n");
		struct cdUCI *pUci = g_node_ht->chi_least_id(id);
		//store msg box
		store_db_hashid(pUci);
		uci_free(pUci);

		//replace
		pUci->uid = id;
		pUci->pUCB = new cdUCB(id);
		uci_set_lastTime(pUci);
		
		ret = 1;	
	}
	
	restore_db_hashid(id);

ih_exit:
	return ret;
*/
#endif
}

struct cdUCI* insert_hashid_fd(long long id)
{
	if (g_node_ht == NULL)
		return NULL;
	return g_node_ht->chi_insert_fd(id);
}

struct cdUCI* get_hashid(long long id)
{
	if (g_node_ht == NULL)
		return NULL;

	return g_node_ht->chi_find_id(id);
}

struct cdUCI* update_hashid(long long id)
{
	struct cdUCI *pUci = get_hashid(id);
	if (pUci != NULL)
	{
		uci_set_lastTime(pUci);
	}

	return pUci;
}

int get_level_status_hashid(long long id, struct levelStatus *pls)
{
	if (pls == NULL)
		return -1;
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
		return 0;
	pls->max_level = ((cdUCB*)(pUci->pUCB))->getMaxLevel();
	pls->lack_level = ((cdUCB*)(pUci->pUCB))->getFirstLackLevel();

	return 1;
}

int update_score_hashid(long long id, int level, int score)
{
	if (g_node_ht == NULL)
		return -1;
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
		return -1;
	int ret = ((cdUCB*)(pUci->pUCB))->updateScore(level, score);
	if (ret < 0)
	{
		return 0;
	}
//	printf("update_score_hashid(), ret:%d\n", ret);

	struct dbMsg msg;

	msg.id = id;
	msg.sdata.level = level;
	msg.sdata.score = score;
	if (ret == 0)
	{
		msg.type = DB_ScoreUpdate;
		//db_update_score(id, level, score);
	}
	else if (ret == 1)
	{
		msg.type = DB_ScoreInsert;
//		db_insert_score(id, level, score);
	}

	db_queue_push(&msg);

	return 1;
}

int update_paidlevel_hashid(long long id, int level)
{
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
		return -1;
	int ret = ((cdUCB*)(pUci->pUCB))->updatePaidLevel(level);
	if (ret == level)
	{
		struct dbMsg msg;
		msg.type = DB_Paidlevel;
		msg.id = id;
		msg.sdata.level = level;
	
		db_queue_push(&msg);
	}

	return ret;
}

int get_paidlevel_hashid(long long id)
{
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
		return -1;

	return ((cdUCB*)(pUci->pUCB))->getPaidLevel();
}

int update_score_list_hashid(long long id, int startLvl, int *scoreList, int count)
{
	if (scoreList == NULL || count <= 0 || startLvl <= 0)
		return -1;
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
		return -1;
	int ret;
	struct dbMsg msg;
	msg.id = id;
	for (int i = 0; i < count; i++)
	{
		ret = ((cdUCB*)(pUci->pUCB))->updateScore(startLvl+i, scoreList[i]);
		if (ret < 0)
		{
			continue;
		}
		if (ret == 0)
		{
		//	db_update_score(id, startLvl+i, scoreList[i]);
			msg.type = DB_ScoreUpdate;
			msg.sdata.level = startLvl+i;
			msg.sdata.score = scoreList[i];
		}
		else if (ret == 1)
		{
		//	db_insert_score(id, startLvl+i, scoreList[i]);
			msg.type = DB_ScoreInsert;
			msg.sdata.level = startLvl+i;
			msg.sdata.score = scoreList[i];
		}

		db_queue_push(&msg);
	}

	return 1;
}

int add_friend_hashid(long long id, long long *frdList, int cnt)
{
	if (g_node_ht == NULL || frdList == NULL)
		return -1;
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
	{
		cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "add_friend_hashid(), id%lld not found!", id);
//		printf("hiaf failed, id:%lld no found!\n");
		return 0;	
	}

	vector<long long> dropList;
	vector<long long> validList;

	struct dbMsg msg;
	struct frdList *pFrdBlock = ((cdUCB*)(pUci->pUCB))->getFriendList();
	if (pFrdBlock->count)
	{
		struct frdList *p = pFrdBlock;

		do
		{
			int count = p->count>MAX_FRIENDS_COUNT?MAX_FRIENDS_COUNT:p->count;
			for (int i = 0; i < count; i++)
			{
				int j;
				for (j = 0; j < cnt; j++)	
				{
					if (p->frdUid[i] == frdList[j])
					{
						validList.push_back(frdList[j]);
						frdList[j] = 0;
						break;
					}
				}
				if (j == cnt)
					dropList.push_back(p->frdUid[i]);
			}
		
			p = p->next;
		}while(p != NULL);

		//delete 
		int count = dropList.size();
		msg.type = DB_FrdDelete;
		for (int i = 0; i < count; i++)
		{
			struct cdUCI *f = get_hashid(dropList[i]);
			if (f != NULL)
				((cdUCB*)(f->pUCB))->removeOneFriend(id);
			((cdUCB*)(pUci->pUCB))->removeOneFriend(dropList[i]);

//			db_delete_friendship(id, dropList[i]);
//			db_delete_friendship(dropList[i], id);
			msg.id = id;
			msg.fid = dropList[i];
			db_queue_push(&msg);
			msg.id = dropList[i];
			msg.fid = id;
			db_queue_push(&msg);
		}

		dropList.clear();
	}

	//add new 
	msg.type = DB_FrdInsert;
	for (int i = 0; i < cnt; i++)
	{
		if (frdList[i] == 0)
			continue;

		struct cdUCI *f = get_hashid(frdList[i]);
		int bInDB = db_find_id(frdList[i]);
		if (f || bInDB)
		{
			int ret = ((cdUCB*)(pUci->pUCB))->addOneFriend(frdList[i]);
			if (ret == 1)
			{
			//	db_insert_friendship(id, frdList[i]);
				msg.id = id;
				msg.fid = frdList[i];

				db_queue_push(&msg);
			}
			if (f != NULL)
				ret = ((cdUCB*)(f->pUCB))->addOneFriend(id);
//			if (ret == 1)
			{
			//	db_insert_friendship(frdList[i], id);
				msg.id = frdList[i];
				msg.fid = id;
			
				db_queue_push(&msg);
			}
			validList.push_back(frdList[i]);
		}
		else
		{
			printf("*");
			cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "add_friend_hashid(), friend:%lld not found.", frdList[i]);
		}
	}

	//return valid friend list
	cnt = validList.size();
	for (int i = 0; i < cnt; i++)
	{
		frdList[i] = validList[i];
//		printf("afh, %d: %lld\n", i, frdList[i]);
	}
	validList.clear();

	return cnt;
}


int add_friend_hashid_fd(long long id, long long *frdList, int cnt)
{
	if (g_node_ht == NULL || frdList == NULL)
		return -1;
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
	{
		cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "add_friend_hashid(), id%lld not found!", id);
		return 0;	
	}

	for (int i = 0; i < cnt; i++)
	{
		struct cdUCI *f = get_hashid(frdList[i]);
		if (f)
		{
			((cdUCB*)(pUci->pUCB))->addOneFriend(frdList[i]);
			((cdUCB*)(f->pUCB))->addOneFriend(id);
		}
		else
		{
			printf("*");
			cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "add_friend_hashid(), friend:%lld not found.", frdList[i]);

		}
	}

	return 1;
}


int push_reqHrtmsg_hashid(long long id)
{
	if (g_node_ht == NULL)
		return 0;
	struct cdUCI *pUci = get_hashid(id);
	if (pUci != NULL)
	{
		struct frdList *fList = ((cdUCB*)(pUci->pUCB))->getFriendList();
		struct hrtMsg msg= {HRT_REQUEST, 0, id};
		
		struct timeval tv;
		gettimeofday(&tv, NULL);
		msg.timestamp = tv.tv_sec;

		while (fList != NULL)
		{
			int cnt = fList->count>MAX_FRIENDS_COUNT?MAX_FRIENDS_COUNT:fList->count;
			for (int i = 0; i < cnt; i++)
			{
				struct cdUCI *f = get_hashid(fList->frdUid[i]);
				if (f != NULL)
				{
					uci_push_msg(f, &msg);
				}		
			}
			fList = fList->next;
		}	
	}
	else
	{
//		printf("push reqhrt no found\n");
		cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "push_reqHrtmsg_hashid(), id:%lld not found", id);
		return 0;
	}

	return 1;
}

int push_giftHrtmsg_hashid(long long id, long long fid)
{
	struct cdUCI *pf = get_hashid(fid);
	if (pf == NULL)
	{
		cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "push_giftHrtmsg_hashid(), friend:%lld not found", fid);
		return 0;
	}

	struct hrtMsg msg = {HRT_GIFT, 0, id};

	struct timeval tv;
	gettimeofday(&tv, NULL);
	msg.timestamp = tv.tv_sec;

//
	uci_push_msg(pf, &msg);

	pf = get_hashid(id);
	if ((pf == NULL) || (pf->mBox == NULL))
	{
		cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "push_giftHrtmsg_hashid(), id:%lld not found", id);
		return 0;
	}
	pf->mBox->chm_devalue_msg(HRT_REQUEST, fid);
	
	return 1;
}

int push_cnfHrtmsg_hashid(long long id, long long fid)
{
	struct cdUCI *pf = get_hashid(fid);
	if (pf == NULL)
	{
		cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "push_cnfHrtmsg_hashid(), friend:%lld not found", fid);
		return 0;
	}

	struct hrtMsg msg = {HRT_CNF, 0, id};

	struct timeval tv;
	gettimeofday(&tv, NULL);
	msg.timestamp = tv.tv_sec;

	uci_push_msg(pf, &msg);

	//
	pf = get_hashid(id);
	if ((pf == NULL) || (pf->mBox == NULL))
	{
		cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "push_cnfHrtmsg_hashid(), id:%lld not found", id);
		return 0;
	}
	pf->mBox->chm_devalue_msg(HRT_GIFT, fid);
	
	return 1;
}

struct hrtMsg* pop_hrtmsg_hashid(long long id)
{
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
	{
		cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "pop_hrtmsg_hashid(), id:%lld not found", id);
		return NULL;
	}
	return uci_pop_msg(pUci);
}

struct hrtMsg* read_hrtmsg_hashid(long long id)
{
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
	{
		cLog::shareLog()->logger(Mod_Cache, Lvl_Warning, "read_hrtmsg_hashid(), id:%lld not found", id);
		return NULL;
	}

	return uci_read_msg(pUci);
}

void dumpMsgTest_hashid(long long id)
{
	struct cdUCI *p = get_hashid(id);
	if (p)
	{
		struct frdList *l = ((cdUCB*)(p->pUCB))->getFriendList();
		int cnt = l->count;
		for (int i = 0; i < cnt; i++)
		{
			struct cdUCI *f = get_hashid(l->frdUid[i]);
			uci_dumpMB(f);
		}
	}
}

//offset start from 1
int get_max_level_friend_hashid(long long id, struct levelInfo *list, int offset, int count)
{
	struct cdUCI *pUci = get_hashid(id);
	if (pUci != NULL)
	{
		struct frdList *p = ((cdUCB*)(pUci->pUCB))->getFriendList();
		if (p->count < offset)
			return 0;
		int cnt = (offset+count - p->count)?(p->count-offset+1):count;
		int hc = offset/MAX_FRIENDS_COUNT;
		int tc = offset%MAX_FRIENDS_COUNT;

		struct frdList *pCur = p;
		for (int i = 0; (i < hc)&&(pCur != NULL); i++)
		{
			pCur = pCur->next;
		}
		int idx = 0;
		int k = 0;
		while (idx < cnt)
		{
			list[idx].friend_id = pCur->frdUid[tc-1+k];
			idx++;
			k++;
			if ((tc+k) >= MAX_FRIENDS_COUNT)
			{
				pCur = pCur->next;
				tc = 1;
				k = 0;
			}
		}

		
		for (int i = 0; i < cnt; i++)
		{
			struct cdUCI *pp = get_hashid(list[i].friend_id);
			if (pp != NULL)
			{
				list[i].max_level = ((cdUCB*)(pp->pUCB))->getMaxLevel();
			}
			else
				cLog::shareLog()->logger(Mod_Cache, Lvl_Error, "get_max_level_friend_hashid() friend:%lld not found", list[i].friend_id);
		}

		return cnt;
	}
	else
		cLog::shareLog()->logger(Mod_Cache, Lvl_Error, "get_max_level_friend_hashi() id%lld not found", id);

	return 0;
}

		
int cmp(const pair<long long, int>& x, const pair<long long, int>& y);

void sortMapValue(map<long long, int>& tMap, vector<pair<long long, int> > & tVector)
{
	for (map<long long, int>::iterator cur=tMap.begin(); cur != tMap.end(); cur++)
	{
		tVector.push_back(make_pair(cur->first, cur->second));
	}
	sort(tVector.begin(), tVector.end(), cmp);
}

int cmp(const pair<long long, int>& x, const pair<long long, int>& y)
{
	return x.second > y.second;
}


int cbs_get_friend_list(long long id, long long **list)
{
	struct cdUCI *pUci = get_hashid(id);
	if (pUci == NULL)
	{
		printf("cbs get id eroor!!!\n");	
		return 0;
	}
	
	int frdCnt = ((cdUCB*)pUci->pUCB)->getFriendCount()+1;

//	printf("get list frd count:%d\n", frdCnt);
	*list = (long long*)malloc(frdCnt*sizeof(long long));
	if (frdCnt > 1)
	{
		((cdUCB*)pUci->pUCB)->getFriendsList(*list);
	}
	//myself
	(*list)[frdCnt-1] = id;

	return frdCnt;	
}

int get_sort_frdlist_hashid(long long id, long long **frdList, int **scoreList, int level)
{
	cldHash *pHt = g_node_ht;
	map<long long, int> ismap;	
	long long *fList;
	int cnt = cbs_get_friend_list(id, &fList);
	if (cnt < 1)
	{
		return 0;
	}

	for (int i = 0; i < cnt; i++)
	{
		struct cdUCI *pIx = pHt->chi_find_id(fList[i]);
		int score = ((cdUCB*)pIx->pUCB)->getScoreOfLevel(level);
		if (score != -1)
		{
			ismap[fList[i]] = score; 
		}
//		printf("frd:%lld score: %d\n", fList[i], score);
	}

	vector<pair<long long, int> > tVec;
	sortMapValue(ismap, tVec);

	int *sList = (int*)malloc(tVec.size()*sizeof(int));
	for (int i = 0; i < tVec.size(); i++)
	{
//		printf("id%lld, score:%d\n", tVec[i].first, tVec[i].second);
		fList[i] = tVec[i].first;
		sList[i] = tVec[i].second;
	}

	*frdList = fList;
	*scoreList = sList;	

	cnt = tVec.size();
	tVec.clear();
	ismap.clear();

	return cnt;
}

