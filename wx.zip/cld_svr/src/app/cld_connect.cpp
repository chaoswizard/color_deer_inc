

int cld_conn::accept(int fd, struct sockaddr_in *addr)
{
    //addr = addr; 
    assert(m_sock == -1);
    assert(fd >= 0);
    
    if (m_poll->add(fd, this) == -1)
        return -1;

    m_poll->set(fd, cld_read) ;
    assert(m_poll->update(fd) == 0);
    
    m_sock = fd;
    m_status = connected;
    
    return 0;
}

int cld_conn::close()
{
    assert(m_status == connecting || m_status == connected);
    
    if (m_poll) 
    {
        assert(m_poll->del(m_poll) == 0);
    }
    ::close(m_sock);
    m_sock = -1;
    m_status = none;
    
    return 0;
}

void cld_conn::on_event(cld_poll *poll, int fd, short event)
{
    if (event & cld_read)
    {
        handle_read();
    }
    
    if (event & cld_write)
    {
        handle_write();
    }
    
    if (event & cld_error)
    {
        handle_error();
    }
}

