#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "svrMsgQueue.h"
//#include "cldLogger.h"

static cldMsgQueue *g_mq = NULL;

int smq_init(void)
{
	if (g_mq == NULL)
	{
		g_mq = new cldMsgQueue();
		if (g_mq == NULL)
			return 0;
	}
	return 1;
}

int smq_push_msg(int len, int type, void *buf)
{
	if (g_mq == NULL)
		return 0;

	struct cldMsg msg = {0};
	msg.len = len+sizeof(struct cldMsg);
	msg.type = type;
	if (len != 0)
	{
		char * dt = (char*)malloc(len);
		memcpy(dt, buf, len);	
		msg.data = dt;
	}
	else
		msg.data = NULL;

	return	g_mq->cmq_push_queue(&msg);	
}

struct cldMsg* smq_pop_msg(void)
{
	if (g_mq == NULL)
		return NULL;

	return g_mq->cmq_pop_queue();
}

