#ifndef _CLD_TIMER_H_
#define _CLD_TIMER_H_

void cld_timer_init(void);
void cld_updatetime(void);
unsigned int cld_gettime(void);



#endif

