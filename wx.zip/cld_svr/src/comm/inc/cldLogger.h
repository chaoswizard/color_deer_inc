#ifndef _CLD_LOGGER_H_
#define _CLD_LOGGER_H_
#include <stdarg.h>
#include <pthread.h>

enum LogModule
{
	Mod_NET,
	Mod_SYS,
	Mod_Cache,
	Mod_DB,
	Mod_MQ,
	Mod_Max
};

enum LogLevel
{
	Lvl_Debug,
	Lvl_Warning,
	Lvl_Backup,
	Lvl_Error,
	Lvl_Critical,
	Lvl_Max
};

class cLog
{
private:
	pthread_mutex_t lock;

	int fd;
	int state;
	void *mp;

	static cLog* pClg;

	cLog();
	~cLog();
public:
	static cLog* shareLog()
	{
		if (pClg == NULL)
			pClg = new cLog();
		return pClg;
	}

	void init(const char *fileName);

	void logger(LogModule mod, LogLevel level, const char *fmt, ...);
};	

//#define cldcLogger	cldLogger::sharedLogger()->cLogger
//#define cldcLogger(mod, level, fmt,...) cldLogger::sharedLogger()->cLogger(mod, level, fmt,##__VA_ARGS__)



#endif

