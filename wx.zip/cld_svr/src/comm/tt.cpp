#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>
#include <string.h>


//char rfile[] = "idlist";
//char wfile[] = "outfile";


#define CLD_FRIEND_SIZE		5//10
#define CLD_FRDLIST_SIZE	50//500
#define CLD_ALL_LIST_SIZE	100//1000


int frd_generate(int *list, int len, int min, int max)
{
	if ((min >= max) || (len <= 0) || (list == NULL))
		return 0;

	int dif = max-min;
	int ss[dif];
	for (int i = 0; i < dif; i++)
		ss[i] = i+1;

	int yy = dif-1;
	int end[dif];
	for (int i = 0; i < dif; i++)
	{
		int idx = (unsigned(rand()))%(yy+1);
		end[i] = ss[idx];
		ss[idx] = ss[yy];
		yy--;
	}
	int outlen = len<dif?len:dif;
	for (int i = 0; i < outlen; i++)
		list[i] = end[i];
	return outlen;
}
	
long long id_generate(void)
{
	int i;
//	srand(unsigned(time(0)));
	long long id = (long long)(1+unsigned(rand())%9)*1000000000;
	long long tail = (long long)((unsigned(rand()))%1000000000);

	return (id+tail);
}	

struct fNode
{
	long long id;
	struct fNode *next;
};
//struct fNode *idlist;
struct sNode
{
	long long id;
	int count;
	struct fNode *next;
};
struct sNode *idlist;
int main(int argc, char *argv[])
{
//	idlist = (struct fNode*)malloc(CLD_ALL_LIST_SIZE*sizeof(struct fNode));
	idlist = (struct sNode*)malloc(CLD_ALL_LIST_SIZE*sizeof(struct sNode));
	if (idlist == NULL)
	{
		printf("idlist malloc failed!\n");
		exit(1);
	}

	srand(unsigned(time(0)));
	printf("list init start!!!\n");

	for (int i = 0; i < CLD_ALL_LIST_SIZE; i++)
	{
		idlist[i].id = id_generate();
		idlist[i].count = 0;	
		idlist[i].next = NULL;
	}

	printf("constructor start!!!\n");

	int frds[CLD_FRIEND_SIZE];	
	for (int i = 0; i < CLD_FRDLIST_SIZE; i++)
	{
		struct fNode *dc = idlist[i].next;
		int count = 0;
		while (dc != NULL)	
		{
			count ++;
			dc = dc->next;
		}
		if (count >= CLD_FRIEND_SIZE)
			continue;

		int cnt = frd_generate(frds, CLD_FRIEND_SIZE-count, i, CLD_FRDLIST_SIZE-1);
		for (int j = 0; j < cnt; j++)
		{
			struct fNode *pf = (struct fNode*)malloc(sizeof(struct fNode));
			pf->id = idlist[i+frds[j]].id;
			pf->next = NULL;
	
			if (idlist[i].next == NULL)
				idlist[i].next = pf;
			else
			{	
			struct fNode *pCur = idlist[i].next;
				
			while (pCur->next != NULL)
				pCur = pCur->next;	
			pCur->next = pf;
			}
			idlist[i].count ++;
	
			struct fNode *pPre = (struct fNode*)malloc(sizeof(struct fNode));
			pPre->id = idlist[i].id;
			pPre->next = NULL;

			if (idlist[i+frds[j]].next == NULL)
				idlist[i+frds[j]].next = pPre;
			else
			{
			struct fNode *pN = idlist[i+frds[j]].next;
			while (pN->next != NULL)
				pN = pN->next;

			pN->next = pPre;
			}
			idlist[i+frds[j]].count ++;
		}
	}
/*
	printf("list dump start!!\n");
	for (int i = 0; i < CLD_ALL_LIST_SIZE; i++)
	{
		printf("i:%d, ", i);
		struct fNode *pCur = &idlist[i];	
		while(pCur != NULL)
		{
			printf("%lld, ", pCur->id);
			pCur = pCur->next;
		}
		printf("\n");
	}
*/
	//client config
	char cn[] = "\n";
	printf("open file start\n");
	int fd;

	fd = open("lt", O_CREAT|O_RDWR);
	if (fd < 0)
	{
		printf(" file open failed!!\n");
	}
	else
	{
		char oline[16] = {0};
		for (int i = 0; i < CLD_ALL_LIST_SIZE; i++)
		{
			sprintf(oline, "%lld ", idlist[i].id);
			write(fd, oline, 11);
			struct fNode *p = idlist[i].next;
			while (p != NULL)
			{
				sprintf(oline, "%lld ", p->id);
			//	oline[10] = ' ';
				write(fd, oline, 11);
				p = p->next;
			}
			write(fd, cn, 1);
		}
	}

	close(fd);


	// id index 
	fd = open("li", O_CREAT|O_RDWR);
	if (fd < 0)
	{
		printf(" file open failed!!\n");
	}
	else
	{
		char line[32] = {0};
		for (int i = 0; i < CLD_ALL_LIST_SIZE; i++)
		{
			sprintf(line, "%lld,%d\n", idlist[i].id, 9990-i*10);
			write(fd, line, 16);
		//	write(fd, cn, 1);
		}	
	}
	close(fd);

	//server config
	fd = open("bcf", O_CREAT|O_RDWR);
	if (fd < 0)
	{
		printf("file bcf open failed!!!\n");
	}
	else
	{
		char sline[16] = {0};
		for (int i = 0; i < CLD_ALL_LIST_SIZE; i++)
		{
			sprintf(sline, "%lld,%2d,", idlist[i].id, idlist[i].count);
			write(fd, sline, 14);
			int cnt = idlist[i].count;
			if (cnt <= 0)
			{	write(fd, cn, 1);
				continue;
			}

			struct fNode *p = idlist[i].next;
			bzero(sline, 16);	
			while (p != NULL)
			{
				sprintf(sline, "%lld,", p->id);
			//	oline[10] = ' ';
				write(fd, sline, 11);
				p = p->next;
			}
			write(fd, cn, 1);
		}
	}

	close(fd);
	////////--------- free ------------
	
	printf("list destructor start!\n");
	for (int i = 0; i < CLD_FRDLIST_SIZE; i++)
	{
		struct fNode *pCur = idlist[i].next;
		struct fNode *pNext = pCur->next;

		while (pNext != NULL)
		{
			free(pCur);
			pCur = pNext;
			pNext = pNext->next;
		}
	}
	printf("delete all list!!!\n");
	free(idlist);
	printf("ok exit\n");	
	

	return 1;
}
