#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>

#include "cldLogger.h"

#define CLG_DEFAULT_PREDIR		"CLDLOG"
#define CLG_MEMPOOL_SIZE		(1024*8)

const char *cLogMod[Mod_Max] = 
{
	"[NET]",
	"[SYS]",
	"[CHE]",
	"[DBA]",
	"[MQB]",
};
const char *cLogLvl[Lvl_Max] = 
{
	"[DEBUG]",
	"[WORNN]",
	"[BACKP]",
	"[ERROR]",
	"[CRITI]",
};
const char cle[] = "\n";

//*****************class cldcLogger  **********************
cLog* cLog::pClg = NULL;

cLog::cLog()
{
	fd = 0;
	state = 0;

	mp = malloc(CLG_MEMPOOL_SIZE);
	
	pthread_mutex_init(&lock, NULL);
}

cLog::~cLog()
{
	if (mp)
		free(mp);
//		delete mp;
	if (fd)
		close(fd);
	state = 0;
	pthread_mutex_destroy(&lock);
}	

void cLog::init(const char *fileName)
{
	if (fileName == NULL)
		return;
	if (fd)
		close(fd);

	fd = open(fileName, O_CREAT|O_RDWR|O_TRUNC, S_IRWXU);
	if (fd < 0)
		printf("cldcLogger open file failed!!\n");
}

void cLog::logger(LogModule mod, LogLevel level, const char *fmt, ...)
{

	time_t rt;
	struct tm *ti;

	time(&rt);
	ti = localtime(&rt);
	
	//lock
	pthread_mutex_lock(&lock);

	char *buf = (char*)mp;

	strftime(buf, 20, "%D %T:", ti);

	memcpy(&buf[18], cLogMod[mod], strlen(cLogMod[mod]));
	memcpy(&buf[23], cLogLvl[level], strlen(cLogLvl[level]));
	
	va_list args;
	int n;
	va_start(args, fmt);
	n = vsprintf(&buf[30], fmt, args);
	va_end(args);

	write(fd, buf, n+30);
	write(fd, cle, 1);
	
//	mp->resetMemPool();
	//unlock	
	pthread_mutex_unlock(&lock);
}


