#ifndef _CLD_HASH_INDEX_H_
#define _CLD_HASH_INDEX_H_
#include "cldUserCacheIndex.h"

#define CHI_HASHTAB_METHOD	1

#if (CHI_HASHTAB_METHOD == 1)
struct chHead
{
	struct cdUCI *pHI;
	int count;
};
#endif

class cldHash
{
	unsigned int cap;
	unsigned int count;
#if (CHI_HASHTAB_METHOD == 0)
	struct cdUCI *hash;
#elif (CHI_HASHTAB_METHOD == 1)
	struct chHead *hTab;
#endif
public:
	cldHash();
	~cldHash();

	struct cdUCI* chi_insert_id(long long id);
	struct cdUCI* chi_find_id(long long id);
	struct cdUCI* chi_insert_fd(long long id);

	int chi_remove_id(long long id);

#if (CHI_HASHTAB_METHOD == 0)
	struct cdUCI* chi_least_id(long long id);	
#endif
};



#endif
