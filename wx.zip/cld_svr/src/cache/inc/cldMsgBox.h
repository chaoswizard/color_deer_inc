#ifndef _CLD_MESSAGE_BOX_H_
#define _CLD_MESSAGE_BOX_H_

enum hMsgType
{
	HRT_REQUEST = 0,
	HRT_GIFT,
	HRT_CNF
};

struct hrtMsg
{
	hMsgType type;
//	int heartCnt;
	long timestamp;
	long long uid;
};

class hrtMsgBox
{
	int size;
	int head;
	int tail;
	int read;
	struct hrtMsg* ms;
public:
	hrtMsgBox();
	~hrtMsgBox();

	int chm_get_cnt_msg(void);
//	int chm_get_cnt_read_msg(void);
	int chm_insert_msg(struct hrtMsg *msg);
	struct hrtMsg* chm_pop_msg(void);
	struct hrtMsg* chm_read_msg(void);

	void chm_devalue_msg(hMsgType type, long long id);
};

#endif

