#ifndef _CLD_USER_CACHE_INDEX_H_
#define _CLD_USER_CACHE_INDEX_H_
#include "cldMsgBox.h"

struct cdUCI
{
	long long uid;
	void *pUCB;
	long lastTime;
	int dirtyFlag;
	hrtMsgBox *mBox;
//	struct cdUCI *next;
};

long long uci_get_id(struct cdUCI *pUci);
void uci_set_id(struct cdUCI *pUci, long long id);
int uci_set_lastTime(struct cdUCI *pUci);
int uci_get_scoreOfLevel(struct cdUCI *pUci);

int uci_get_msg_count(struct cdUCI *pUci);
int uci_push_msg(struct cdUCI *pUci, struct hrtMsg *msg);
struct hrtMsg* uci_pop_msg(struct cdUCI *pUci);
struct hrtMsg* uci_read_msg(struct cdUCI *pUci);

int uci_set_dirtyFlag(struct cdUCI *pUci);
void uci_free(struct cdUCI *pUci);

void uci_dumpMB(struct cdUCI *pUci);
void uci_dumpInfo(struct cdUCI *pUci);

#endif

