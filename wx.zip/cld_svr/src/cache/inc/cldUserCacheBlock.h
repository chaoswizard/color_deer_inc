#ifndef _CLD_USER_CACHE_BLOCK_H_
#define _CLD_USER_CACHE_BLOCK_H_

//#include <types.h>

#define UCB_MAX_ITEM		100
#define MAX_FRIENDS_COUNT	31


//friends list struct
struct frdList
{
	int count;
	struct frdList *next;
	long long frdUid[MAX_FRIENDS_COUNT];
	//int64_t	frdUid[MAX_FRIENDS_COUNT];
};

class cdUCB 
{
	//int64_t uid;
	long long uid;

	//last paid level
	int paidLevel;

	//score struct
	int lastLvl;
	int scores[UCB_MAX_ITEM];
	short timeStramp[UCB_MAX_ITEM];

	//friends list struct
	struct frdList frdInfo;
public:
	cdUCB(void);
	cdUCB(long long id);
	~cdUCB(void);

	static cdUCB* create(long long id);

	void setID(long long id);
	long long getUID(void);

	int updateScore(int level, int score);
	int getScoreOfLevel(int level);
	int getMaxLevel(void);
	int getFirstLackLevel(void);

	int updatePaidLevel(int level);
	int getPaidLevel(void);
	
	int setFriendsList(long long *pList, int count);
	int getFriendsList(long long *pList);
	
	struct frdList* getFriendList(void);
	int getFriendCount(void);
	int addOneFriend(long long id);
	int removeOneFriend(long long id);

	void dumpInfo(void);	
};



#endif

