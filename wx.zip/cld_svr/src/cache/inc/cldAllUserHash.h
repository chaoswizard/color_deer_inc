#ifndef _CLD_ALL_USER_HASH_H_
#define _CLD_ALL_USER_HASH_H_

class userTab
{
	unsigned int cap;
	unsigned int count;

	long long *ht;

	static userTab *ut;
 
	userTab();
	~userTab();
public:

	static userTab* shareUT(void)
	{
		if (ut == NULL)
			ut = new userTab();
		return ut;
	}

	int push_id(long long id);
	int find_id(long long id);
};



#endif

