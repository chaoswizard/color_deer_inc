#ifndef _CLD_MESSAGE_H_
#define _CLD_MESSAGE_H_
#include <pthread.h>

#define CMQ_CONTENT_SIZE	48

struct cldMsg
{
	int len;
	int type;
//	char pData[CMQ_CONTENT_SIZE];
	void *data;
};


struct msgScore
{
	int level;
	int score;
};

class cldMsgQueue
{
public:
	cldMsgQueue(void);
	~cldMsgQueue(void);

//	int cmq_push_queue(int len, int type, const void * buf);
	int cmq_push_queue(struct cldMsg *msg);
	struct cldMsg* cmq_pop_queue(void);
private:
	pthread_rwlock_t lock;
	struct cldMsg *mq;
	int head;
	int tail;
	int size;
};
#endif
