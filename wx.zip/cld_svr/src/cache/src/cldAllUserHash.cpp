#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "cldAllUserHash.h"

#define CUT_MAX_SIZE	(2*64*2048)

userTab* userTab::ut = NULL;

userTab::userTab()
{
	count = 0;
	cap = CUT_MAX_SIZE;
	ht = (long long*)malloc(cap*sizeof(long long));
	bzero(ht, cap*sizeof(long long));
}

userTab::~userTab()
{
	if (ht)
		free(ht);
}

int userTab::push_id(long long id)
{
	unsigned int key = id%cap;

	for (int i = 0; i < cap; i++)
	{
		if (ht[key] == 0)
		{
			ht[key] = id;
			count ++;
			return 1;
		}
		else if (ht[key] == id)
		{
			return 0;
		}

		key = (key+1)%cap;
	}

	return -1;
}

int userTab::find_id(long long id)
{
	unsigned int key = id%cap;

	for (int i = 0; i < cap; i++)
	{
		if (ht[key] == id)
			return 1;
		key = (key+1)%cap;
	}
	return 0;
}
