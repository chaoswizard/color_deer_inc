#include <stdio.h>
#include <stdlib.h>
#include "cldUserCacheIndex.h"
#include <sys/time.h>
#include "cldUserCacheBlock.h"

void uci_set_id(struct cdUCI *pUci, long long id)
{
	if (pUci == NULL)
		return;

	pUci->uid = id;
}

long long uci_get_id(struct cdUCI *pUci)
{
	if (pUci == NULL)
		return -1;

	return pUci->uid;
}

static int uci_init_msgBox(struct cdUCI *pUci)
{
	if (pUci == NULL)
		return -1;

	pUci->mBox = new hrtMsgBox();
	if (pUci->mBox == NULL)
	{
		printf("uci init msg box malloc faile!!!\n");
		return 0;
	}

	return 1;
}


int uci_get_msg_count(struct cdUCI *pUci)
{
	if (pUci == NULL || pUci->mBox == NULL)
		return 0;
	return pUci->mBox->chm_get_cnt_msg();
}

int uci_push_msg(struct cdUCI *pUci, struct hrtMsg *msg)
{
	if (pUci == NULL || msg == NULL)
		return 0;
	if (pUci->mBox == NULL)
		uci_init_msgBox(pUci);
	if (pUci->mBox != NULL)
	{
		return	pUci->mBox->chm_insert_msg(msg);
	}

	return 0;
}

struct hrtMsg* uci_pop_msg(struct cdUCI *pUci)
{
	if (pUci == NULL || pUci->mBox == NULL)
		return NULL;

	return pUci->mBox->chm_pop_msg();
}

struct hrtMsg* uci_read_msg(struct cdUCI *pUci)
{
	if (pUci == NULL || pUci->mBox == NULL)
		return NULL;
	return pUci->mBox->chm_read_msg();
}

int uci_set_lastTime(struct cdUCI *pUci)
{
	if (pUci == NULL)
		return -1;

	struct timeval tv;
	gettimeofday(&tv, NULL);

	pUci->lastTime = tv.tv_sec;

	return 1;
}

int uci_get_scoreOfLevel(struct cdUCI *pUci, int level)
{
	if (pUci == NULL || pUci->pUCB == NULL)
		return -1;

	return ((cdUCB*)pUci->pUCB)->getScoreOfLevel(level);
}

void uci_free(struct cdUCI *pUci)
{
	if (pUci == NULL)
		return;
	if (pUci->pUCB != NULL)
	{
		delete (cdUCB*)(pUci->pUCB);
		pUci->pUCB = NULL;
	}

	if (pUci->mBox != NULL)
	{
		delete pUci->mBox;
		pUci->mBox = NULL;
	}

	pUci->uid = 0;
	pUci->lastTime = 0;

}

void uci_dumpMB(struct cdUCI *pUci)
{
	if (pUci == NULL)
		return;
	printf("---- uci msg dump ----\n");
	struct hrtMsg *msg;
	while ((msg = pUci->mBox->chm_pop_msg()) != NULL)
	{
		printf("id:%lld, msg, type:%d, frd:%lld\n", pUci->uid, msg->type, msg->uid);
	}
	printf("---- end msg dump ----\n");
}


void uci_dumpInfo(struct cdUCI *pUci)
{
	printf("---uci info---\n");
	if (pUci == NULL)
	{
		printf("pUci is null, fails\n");
		return;
	}
	printf("uid: %d\n", pUci->uid);
	printf("ucb addr: 0x%x\n", pUci->pUCB);
	printf("last time: %d\n", pUci->lastTime);
	printf("msg box addr: 0x%x\n", pUci->mBox);
	printf("---end uci---\n");
}
