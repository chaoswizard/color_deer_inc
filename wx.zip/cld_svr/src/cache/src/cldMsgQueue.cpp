#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "cldMsgQueue.h"
#include "cldLogger.h"

#define CMQ_DEF_SIZE	1024

cldMsgQueue::cldMsgQueue(void)
{
	pthread_rwlock_init(&lock, NULL);

	size = CMQ_DEF_SIZE;
	head = 0;
	tail = 0;
	mq = (struct cldMsg*)malloc(CMQ_DEF_SIZE*sizeof(struct cldMsg));
	if (mq == NULL)
		printf("cld msg queue malloc fails!\n");
}

cldMsgQueue::~cldMsgQueue(void)
{
	struct cldMsg *m = cmq_pop_queue();
	while (m)
	{
		free(m->data);
		m = cmq_pop_queue();
	}

	free(mq);
	
	pthread_rwlock_destroy(&lock);
}

int cldMsgQueue::cmq_push_queue(struct cldMsg *msg)
{
	if (msg == NULL)
		return 0;

	if (((tail+1)%size) == head)
	{
		pthread_rwlock_wrlock(&lock);

		struct cldMsg *new_buf = (struct cldMsg*)malloc(size*2*sizeof(struct cldMsg));
		for (int i = 0; i < size-1; i++)
		{
			new_buf[i] = mq[(i+head)%size];
		}
		free(mq);
		mq = new_buf;
		head = 0;
		tail = size - 1;
		size *= 2;

		pthread_rwlock_unlock(&lock);

		cLog::shareLog()->logger(Mod_MQ, Lvl_Critical, "mq expend 2X, size%d", size);
	}

	struct cldMsg *slot = &mq[tail];
	memcpy(slot, msg, sizeof(struct cldMsg));
	tail = (tail+1)%size;
	
	return 1;
}

struct cldMsg* cldMsgQueue::cmq_pop_queue(void)
{
//	printf("cmq_pop_queue, head:%d, tail:%d\n", head, tail);
	if (head == tail)
		return NULL;

	pthread_rwlock_rdlock(&lock);
	
	struct cldMsg *msg = &mq[head];
	head = (head+1)%size;

	pthread_rwlock_unlock(&lock);

	return msg;
}

