#include <stdlib.h>
#include <stdio.h>
#include "cldMsgBox.h"
#include <string.h>

#define CHM_MAX_SIZE	32


hrtMsgBox::hrtMsgBox()
{

	size = CHM_MAX_SIZE;
	head = 0;
	tail = 0;
	read = 0;
	ms = (struct hrtMsg*)malloc(CHM_MAX_SIZE*sizeof(struct hrtMsg));
	if (ms == NULL)
		printf("heart message box malloc failed!!!!\n");

}

hrtMsgBox::~hrtMsgBox()
{
	if (ms != NULL)
		free(ms);
}

int hrtMsgBox::chm_get_cnt_msg(void)
{
	read = tail;
	if (tail > head)
		return (head+size-tail);

	return (head-tail);
}

int hrtMsgBox::chm_insert_msg(struct hrtMsg *msg)
{
//	printf("chm_insert_msg(), type:%d\n", msg->type);
	if ((head+1)%size == tail)
	{
		//msg box full
		return 0;
/*
		struct hrtMsg *new_buf = (struct hrtMsg*)malloc(2*size*sizeof(struct hrtMsg));
		for (int i = 0; i < size-1; i++)
			new_buf[i] = ms[(head+i)%size];
		free(ms);
		ms = new_buf;
		tail = 0;
		read = 0;
		head = size-1;
		size *= 2;
*/
	}

	struct hrtMsg *pCur = &ms[head];
	memcpy(pCur, msg, sizeof(*msg));
	head = (head+1)%size;

	return 1;
}

struct hrtMsg* hrtMsgBox::chm_pop_msg(void)
{
	if (head == tail)
		return NULL;

	struct hrtMsg *msg = &ms[tail];
	tail = (tail+1)%size;
	read = tail;
	
	return msg;
}

struct hrtMsg* hrtMsgBox::chm_read_msg(void)
{
	if (head == read)
		return NULL;

	struct hrtMsg *msg = &ms[read];
	read = (read+1)%size;

	return msg;
}

void hrtMsgBox::chm_devalue_msg(hMsgType type, long long id)
{
	if (tail == head)
		return;

	int idx = tail;
	int count = (read>=tail)?(read-tail):(size+read-tail);

	for (int i = 0; i < count; i++)
	{
		if ((ms[idx].type == type) && (ms[idx].uid == id) && (ms[idx].timestamp != 0))
		{
			ms[idx].timestamp = 0;
			break;
		}
		idx = (idx+1)%size;
	}
}
