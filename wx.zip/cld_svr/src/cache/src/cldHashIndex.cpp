#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "cldHashIndex.h"
#include "cldUserCacheBlock.h"

#if (CHI_HASHTAB_METHOD == 0)
#define CHI_MAX_SIZE		(64*2048)
#define CHI_LEAST_COUNT		(CHI_MAX_SIZE/128)
#endif

//#elif (CHI_HASHTAB_METHOD == 1)

#define CHI_HASHTAB_ROW		2048
#define CHI_HASHTAB_COL		64
//#endif

#define CHI_CRC_SIZE		256
const static unsigned int crc32tab[CHI_CRC_SIZE] = 
{
	0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f, 0xe963a535, 0x9e6495a3,
	0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988, 0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 
	0x1db71064, 0x6ab020f2, 0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7, 
	0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9, 0xfa0f3d63, 0x8d080df5, 
	0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172, 0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 
	0x35b5a8fa, 0x42b2986c, 0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59, 
	0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423, 0xcfba9599, 0xb8bda50f, 
	0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924, 0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 
	0x76dc4190, 0x01db7106, 0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433, 
	0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d, 0x91646c97, 0xe6635c01, 
	0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e, 0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 
	0x65b0d9c6, 0x12b7e950, 0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65, 
	0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7, 0xa4d1c46d, 0xd3d6f4fb, 
	0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0, 0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 
	0x5005713c, 0x270241aa, 0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f, 
	0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81, 0xb7bd5c3b, 0xc0ba6cad, 
	0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a, 0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683, 
	0xe3630b12, 0x94643b84, 0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1, 
	0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb, 0x196c3671, 0x6e6b06e7, 
	0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc, 0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 
	0xd6d6a3e8, 0xa1d1937e, 0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
	0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55, 0x316e8eef, 0x4669be79, 
	0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236, 0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 
	0xc5ba3bbe, 0xb2bd0b28, 0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d, 
	0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f, 0x72076785, 0x05005713, 
	0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38, 0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21, 
	0x86d3d2d4, 0xf1d4e242, 0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777, 
	0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69, 0x616bffd3, 0x166ccf45, 
	0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2, 0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 
	0xaed16a4a, 0xd9d65adc, 0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9, 
	0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693, 0x54de5729, 0x23d967bf, 
	0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94, 0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
};

const unsigned long long crc64tab[CHI_CRC_SIZE] = 
{	    
	0x0000000000000000ULL, 0xB32E4CBE03A75F6FULL, 0xF4843657A840A05BULL, 0x47AA7AE9ABE7FF34ULL,
	0x7BD0C384FF8F5E33ULL, 0xC8FE8F3AFC28015CULL, 0x8F54F5D357CFFE68ULL, 0x3C7AB96D5468A107ULL,
	0xF7A18709FF1EBC66ULL, 0x448FCBB7FCB9E309ULL, 0x0325B15E575E1C3DULL, 0xB00BFDE054F94352ULL,
	0x8C71448D0091E255ULL, 0x3F5F08330336BD3AULL, 0x78F572DAA8D1420EULL, 0xCBDB3E64AB761D61ULL,
	0x7D9BA13851336649ULL, 0xCEB5ED8652943926ULL, 0x891F976FF973C612ULL, 0x3A31DBD1FAD4997DULL,
	0x064B62BCAEBC387AULL, 0xB5652E02AD1B6715ULL, 0xF2CF54EB06FC9821ULL, 0x41E11855055BC74EULL,
	0x8A3A2631AE2DDA2FULL, 0x39146A8FAD8A8540ULL, 0x7EBE1066066D7A74ULL, 0xCD905CD805CA251BULL,
	0xF1EAE5B551A2841CULL, 0x42C4A90B5205DB73ULL, 0x056ED3E2F9E22447ULL, 0xB6409F5CFA457B28ULL,
	0xFB374270A266CC92ULL, 0x48190ECEA1C193FDULL, 0x0FB374270A266CC9ULL, 0xBC9D3899098133A6ULL,
	0x80E781F45DE992A1ULL, 0x33C9CD4A5E4ECDCEULL, 0x7463B7A3F5A932FAULL, 0xC74DFB1DF60E6D95ULL,
	0x0C96C5795D7870F4ULL, 0xBFB889C75EDF2F9BULL, 0xF812F32EF538D0AFULL, 0x4B3CBF90F69F8FC0ULL,
	0x774606FDA2F72EC7ULL, 0xC4684A43A15071A8ULL, 0x83C230AA0AB78E9CULL, 0x30EC7C140910D1F3ULL,
	0x86ACE348F355AADBULL, 0x3582AFF6F0F2F5B4ULL, 0x7228D51F5B150A80ULL, 0xC10699A158B255EFULL,
	0xFD7C20CC0CDAF4E8ULL, 0x4E526C720F7DAB87ULL, 0x09F8169BA49A54B3ULL, 0xBAD65A25A73D0BDCULL,
	0x710D64410C4B16BDULL, 0xC22328FF0FEC49D2ULL, 0x85895216A40BB6E6ULL, 0x36A71EA8A7ACE989ULL,
	0x0ADDA7C5F3C4488EULL, 0xB9F3EB7BF06317E1ULL, 0xFE5991925B84E8D5ULL, 0x4D77DD2C5823B7BAULL,
	0x64B62BCAEBC387A1ULL, 0xD7986774E864D8CEULL, 0x90321D9D438327FAULL, 0x231C512340247895ULL,
	0x1F66E84E144CD992ULL, 0xAC48A4F017EB86FDULL, 0xEBE2DE19BC0C79C9ULL, 0x58CC92A7BFAB26A6ULL,
	0x9317ACC314DD3BC7ULL, 0x2039E07D177A64A8ULL, 0x67939A94BC9D9B9CULL, 0xD4BDD62ABF3AC4F3ULL,
	0xE8C76F47EB5265F4ULL, 0x5BE923F9E8F53A9BULL, 0x1C4359104312C5AFULL, 0xAF6D15AE40B59AC0ULL,
	0x192D8AF2BAF0E1E8ULL, 0xAA03C64CB957BE87ULL, 0xEDA9BCA512B041B3ULL, 0x5E87F01B11171EDCULL,
	0x62FD4976457FBFDBULL, 0xD1D305C846D8E0B4ULL, 0x96797F21ED3F1F80ULL, 0x2557339FEE9840EFULL,
	0xEE8C0DFB45EE5D8EULL, 0x5DA24145464902E1ULL, 0x1A083BACEDAEFDD5ULL, 0xA9267712EE09A2BAULL,
	0x955CCE7FBA6103BDULL, 0x267282C1B9C65CD2ULL, 0x61D8F8281221A3E6ULL, 0xD2F6B4961186FC89ULL,
	0x9F8169BA49A54B33ULL, 0x2CAF25044A02145CULL, 0x6B055FEDE1E5EB68ULL, 0xD82B1353E242B407ULL,
	0xE451AA3EB62A1500ULL, 0x577FE680B58D4A6FULL, 0x10D59C691E6AB55BULL, 0xA3FBD0D71DCDEA34ULL,
	0x6820EEB3B6BBF755ULL, 0xDB0EA20DB51CA83AULL, 0x9CA4D8E41EFB570EULL, 0x2F8A945A1D5C0861ULL,
	0x13F02D374934A966ULL, 0xA0DE61894A93F609ULL, 0xE7741B60E174093DULL, 0x545A57DEE2D35652ULL,
	0xE21AC88218962D7AULL, 0x5134843C1B317215ULL, 0x169EFED5B0D68D21ULL, 0xA5B0B26BB371D24EULL,
	0x99CA0B06E7197349ULL, 0x2AE447B8E4BE2C26ULL, 0x6D4E3D514F59D312ULL, 0xDE6071EF4CFE8C7DULL,
	0x15BB4F8BE788911CULL, 0xA6950335E42FCE73ULL, 0xE13F79DC4FC83147ULL, 0x521135624C6F6E28ULL,
	0x6E6B8C0F1807CF2FULL, 0xDD45C0B11BA09040ULL, 0x9AEFBA58B0476F74ULL, 0x29C1F6E6B3E0301BULL,
	0xC96C5795D7870F42ULL, 0x7A421B2BD420502DULL, 0x3DE861C27FC7AF19ULL, 0x8EC62D7C7C60F076ULL,
	0xB2BC941128085171ULL, 0x0192D8AF2BAF0E1EULL, 0x4638A2468048F12AULL, 0xF516EEF883EFAE45ULL,
	0x3ECDD09C2899B324ULL, 0x8DE39C222B3EEC4BULL, 0xCA49E6CB80D9137FULL, 0x7967AA75837E4C10ULL,
	0x451D1318D716ED17ULL, 0xF6335FA6D4B1B278ULL, 0xB199254F7F564D4CULL, 0x02B769F17CF11223ULL,
	0xB4F7F6AD86B4690BULL, 0x07D9BA1385133664ULL, 0x4073C0FA2EF4C950ULL, 0xF35D8C442D53963FULL,
	0xCF273529793B3738ULL, 0x7C0979977A9C6857ULL, 0x3BA3037ED17B9763ULL, 0x888D4FC0D2DCC80CULL,
	0x435671A479AAD56DULL, 0xF0783D1A7A0D8A02ULL, 0xB7D247F3D1EA7536ULL, 0x04FC0B4DD24D2A59ULL,
	0x3886B22086258B5EULL, 0x8BA8FE9E8582D431ULL, 0xCC0284772E652B05ULL, 0x7F2CC8C92DC2746AULL,
	0x325B15E575E1C3D0ULL, 0x8175595B76469CBFULL, 0xC6DF23B2DDA1638BULL, 0x75F16F0CDE063CE4ULL,
	0x498BD6618A6E9DE3ULL, 0xFAA59ADF89C9C28CULL, 0xBD0FE036222E3DB8ULL, 0x0E21AC88218962D7ULL,
	0xC5FA92EC8AFF7FB6ULL, 0x76D4DE52895820D9ULL, 0x317EA4BB22BFDFEDULL, 0x8250E80521188082ULL,
	0xBE2A516875702185ULL, 0x0D041DD676D77EEAULL, 0x4AAE673FDD3081DEULL, 0xF9802B81DE97DEB1ULL,
	0x4FC0B4DD24D2A599ULL, 0xFCEEF8632775FAF6ULL, 0xBB44828A8C9205C2ULL, 0x086ACE348F355AADULL,
	0x34107759DB5DFBAAULL, 0x873E3BE7D8FAA4C5ULL, 0xC094410E731D5BF1ULL, 0x73BA0DB070BA049EULL,
	0xB86133D4DBCC19FFULL, 0x0B4F7F6AD86B4690ULL, 0x4CE50583738CB9A4ULL, 0xFFCB493D702BE6CBULL,
	0xC3B1F050244347CCULL, 0x709FBCEE27E418A3ULL, 0x3735C6078C03E797ULL, 0x841B8AB98FA4B8F8ULL,
	0xADDA7C5F3C4488E3ULL, 0x1EF430E13FE3D78CULL, 0x595E4A08940428B8ULL, 0xEA7006B697A377D7ULL,
	0xD60ABFDBC3CBD6D0ULL, 0x6524F365C06C89BFULL, 0x228E898C6B8B768BULL, 0x91A0C532682C29E4ULL,
	0x5A7BFB56C35A3485ULL, 0xE955B7E8C0FD6BEAULL, 0xAEFFCD016B1A94DEULL, 0x1DD181BF68BDCBB1ULL,
	0x21AB38D23CD56AB6ULL, 0x9285746C3F7235D9ULL, 0xD52F0E859495CAEDULL, 0x6601423B97329582ULL,
	0xD041DD676D77EEAAULL, 0x636F91D96ED0B1C5ULL, 0x24C5EB30C5374EF1ULL, 0x97EBA78EC690119EULL,
	0xAB911EE392F8B099ULL, 0x18BF525D915FEFF6ULL, 0x5F1528B43AB810C2ULL, 0xEC3B640A391F4FADULL,
	0x27E05A6E926952CCULL, 0x94CE16D091CE0DA3ULL, 0xD3646C393A29F297ULL, 0x604A2087398EADF8ULL,
	0x5C3099EA6DE60CFFULL, 0xEF1ED5546E415390ULL, 0xA8B4AFBDC5A6ACA4ULL, 0x1B9AE303C601F3CBULL,
	0x56ED3E2F9E224471ULL, 0xE5C372919D851B1EULL, 0xA26908783662E42AULL, 0x114744C635C5BB45ULL,
	0x2D3DFDAB61AD1A42ULL, 0x9E13B115620A452DULL, 0xD9B9CBFCC9EDBA19ULL, 0x6A978742CA4AE576ULL,
	0xA14CB926613CF817ULL, 0x1262F598629BA778ULL, 0x55C88F71C97C584CULL, 0xE6E6C3CFCADB0723ULL,
	0xDA9C7AA29EB3A624ULL, 0x69B2361C9D14F94BULL, 0x2E184CF536F3067FULL, 0x9D36004B35545910ULL,
	0x2B769F17CF112238ULL, 0x9858D3A9CCB67D57ULL, 0xDFF2A94067518263ULL, 0x6CDCE5FE64F6DD0CULL,
	0x50A65C93309E7C0BULL, 0xE388102D33392364ULL, 0xA4226AC498DEDC50ULL, 0x170C267A9B79833FULL,
	0xDCD7181E300F9E5EULL, 0x6FF954A033A8C131ULL, 0x28532E49984F3E05ULL, 0x9B7D62F79BE8616AULL,
	0xA707DB9ACF80C06DULL, 0x14299724CC279F02ULL, 0x5383EDCD67C06036ULL, 0xE0ADA17364673F59ULL
};

static unsigned int cldHashkey(unsigned long long value, unsigned int *low)
{
	unsigned int index = value&(CHI_CRC_SIZE-1);
	unsigned long long key = value^crc64tab[index];
	*low = (key>>32)&(CHI_HASHTAB_COL-1);	
	return key&(CHI_HASHTAB_ROW-1);
}

cldHash::cldHash(void)
{
#if (CHI_HASHTAB_METHOD == 0)
	cap = CHI_MAX_SIZE;
	count = 0;
	hash = (struct cdUCI*)malloc(CHI_MAX_SIZE*sizeof(struct cdUCI));
	if (hash == NULL)
		printf("cld hash malloc fails!!!");

	memset(hash, 0, CHI_MAX_SIZE*sizeof(struct cdUCI));

#elif (CHI_HASHTAB_METHOD == 1)

	cap = CHI_HASHTAB_ROW*CHI_HASHTAB_COL;
	count = 0;
	hTab = (struct chHead*)malloc(CHI_HASHTAB_ROW*sizeof(struct chHead));

	for (int i = 0;  i < CHI_HASHTAB_ROW; i++)
	{
		hTab[i].pHI = (struct cdUCI*)malloc(CHI_HASHTAB_COL*sizeof(struct cdUCI));
		hTab[i].count = 0;
		memset(hTab[i].pHI, 0, CHI_HASHTAB_COL*sizeof(struct cdUCI));
	}
#endif
}

cldHash::~cldHash(void)
{
#if (CHI_HASHTAB_METHOD == 0)
	struct cdUCI *pUci = hash;

	for (int i = 0; i < cap; i++)
		delete	(cdUCB*)pUci[i].pUCB;
	free(hash);	

#elif (CHI_HASHTAB_METHOD == 1)
	struct chHead *p = hTab;
	for (int i = 0; i < CHI_HASHTAB_ROW; i++)
	{
		struct cdUCI *pI = p->pHI;
		for (int j = 0; j < CHI_HASHTAB_COL; j++)
		{
			if (pI->pUCB != NULL)
				delete (cdUCB*)pI->pUCB;
			pI++;
		}
		free(p->pHI);
		p++;
	}

	free(hTab);
#endif
}

struct cdUCI* cldHash::chi_insert_id(long long id)
{
#if (CHI_HASHTAB_METHOD == 1)
	unsigned int low;
	unsigned int key = cldHashkey(id, &low);

	long lastTime = hTab[key].pHI[low].lastTime;
	int lstIdx = low;
	int index = low;

	int i;
	for (i = 0; i < CHI_HASHTAB_COL; i++)
	{
		if ((hTab[key].pHI[index].uid == 0) || (hTab[key].pHI[index].uid == id))
			break;
		if (lastTime > hTab[key].pHI[index].lastTime)
		{
			lastTime = hTab[key].pHI[index].lastTime;
			lstIdx = index;
		}
		index = (index+1)&(CHI_HASHTAB_COL-1);
	}
	if (i == CHI_HASHTAB_COL)
	{
		//replace
		struct cdUCI *pInvalid = (struct cdUCI*)malloc(sizeof(struct cdUCI));
		memcpy(pInvalid, &(hTab[key].pHI[lstIdx]), sizeof(struct cdUCI));
		if (pInvalid->pUCB)
		{
			delete (cdUCB*)(pInvalid->pUCB);
			pInvalid->pUCB = NULL;
		}

		hTab[key].pHI[lstIdx].uid = id;
		hTab[key].pHI[lstIdx].pUCB = new cdUCB(id);
		uci_set_lastTime(&(hTab[key].pHI[lstIdx]));

		return pInvalid;
	}

	if (id != hTab[key].pHI[index].uid)
	{
		hTab[key].pHI[index].uid = id;
		hTab[key].pHI[index].pUCB = new cdUCB(id);
		hTab[key].count ++;
	}
	uci_set_lastTime(&(hTab[key].pHI[index]));

	count ++;
	
	return &(hTab[key].pHI[index]);
#elif (CHI_HASHTAB_METHOD == 0)
	unsigned int key = id%cap;
	
	long lastTime = hash[key].lastTime;
	int lstIdx = key;

	int i;
	for (i = 0; i < cap; i++)
	{
		if (hash[key].uid == 0)
			break;
	//	else
	//		printf("@");
		if (hash[key].uid == id)
		{
			uci_set_lastTime(&hash[key]);
			printf("#%lld\n", id);
			return &hash[key];
		}
		if (lastTime > hash[key].lastTime)
		{
			lastTime = hash[key].lastTime;
			lstIdx = key;
		}
		key = (key+1)%cap;
	}
	if (i == cap)
	{
		struct cdUCI *pd = (struct cdUCI*)malloc(sizeof(struct cdUCI));
		memcpy(pd, &hash[lstIdx], sizeof(struct cdUCI));
		
		if (pd->pUCB)
		{
			delete (cdUCB*)(pd->pUCB);
			pd->pUCB = NULL;
		}
		count --;
		key = lstIdx;
	}

	hash[key].uid = id;
	hash[key].pUCB = new cdUCB(id);
	uci_set_lastTime(&hash[key]);	

	count ++;	

	return &hash[key];
#endif
}


struct cdUCI* cldHash::chi_insert_fd(long long id)
{
#if (CHI_HASHTAB_METHOD == 1)
	unsigned int low;
	unsigned int key = cldHashkey(id, &low);

	long lastTime = hTab[key].pHI[low].lastTime;
	int lstIdx = low;
	int index = low;

	int i;
	for (i = 0; i < CHI_HASHTAB_COL; i++)
	{
		if ((hTab[key].pHI[index].uid == 0) || (hTab[key].pHI[index].uid == id))
			break;
		if (lastTime > hTab[key].pHI[index].lastTime)
		{
			lastTime = hTab[key].pHI[index].lastTime;
			lstIdx = index;
		}
		index = (index+1)&(CHI_HASHTAB_COL-1);
	}
	if (i == CHI_HASHTAB_COL)
	{
		//replace
	//	struct cdUCI *pInvalid = (struct cdUCI*)malloc(sizeof(struct cdUCI));
	//	memcpy(pInvalid, &(hTab[key].pHI[lstIdx]), sizeof(struct cdUCI));
		if (hTab[key].pHI[lstIdx].pUCB)
		{
			delete (cdUCB*)(hTab[key].pHI[lstIdx].pUCB);
			hTab[key].pHI[lstIdx].pUCB = NULL;
		}

		if (hTab[key].pHI[lstIdx].mBox)
		{
			delete hTab[key].pHI[lstIdx].mBox;
			hTab[key].pHI[lstIdx].mBox = NULL;
		}
		count --;
		index = lstIdx;
	}

	if (id != hTab[key].pHI[index].uid)
	{
		hTab[key].pHI[index].uid = id;
		hTab[key].pHI[index].pUCB = new cdUCB(id);
		hTab[key].count ++;
	}
	uci_set_lastTime(&(hTab[key].pHI[index]));

	count ++;
	
	return &(hTab[key].pHI[index]);
#elif (CHI_HASHTAB_METHOD == 0)
	if (count >= (cap-1))
		return NULL;

	unsigned int key = id%cap;
	
	int i;
	for (i = 0; i < cap; i++)
	{
		if (hash[key].uid == 0)
			break;
		else
			printf("@");
		if (hash[key].uid == id)
		{
			uci_set_lastTime(&hash[key]);
			printf("#%lld\n", id);
			return &hash[key];
		}
		key = (key+1)%cap;
	}
	if (i == cap)
		return NULL;	

	hash[key].uid = id;
	hash[key].pUCB = new cdUCB(id);
	uci_set_lastTime(&hash[key]);	

	count ++;	

	return &hash[key];
#endif
}
#if (CHI_HASHTAB_METHOD == 0)
struct cdUCI* cldHash::chi_least_id(long long id)
{
	unsigned int key = id%cap;

	int leastIdx = key;
	long leastTime = hash[key].lastTime;
	for (int i = 0; i < CHI_LEAST_COUNT; i++)
	{
		if (leastTime > hash[key].lastTime)
		{
			leastTime = hash[key].lastTime;
			leastIdx = key;
		}	

		key = (key+1)%cap;
	} 

	return &hash[leastIdx];
}
#endif

struct cdUCI* cldHash::chi_find_id(long long id)
{
#if (CHI_HASHTAB_METHOD == 0)
	unsigned int key = id%cap;

	while (hash[key].uid != 0)
	{
		if (hash[key].uid == id)
			return &hash[key];
		key = (key+1)%cap;
	}
	return NULL;
#elif (CHI_HASHTAB_METHOD == 1)
	unsigned int low;
	unsigned int key = cldHashkey(id, &low);

	int i;
	for (i = 0 ; i< CHI_HASHTAB_COL; i++)
	{
		if (hTab[key].pHI[low].uid == id)
		{
			return &(hTab[key].pHI[low]);
		}
		low = (low+1)&(CHI_HASHTAB_COL-1);
	}

	return NULL;
#endif
}

int cldHash::chi_remove_id(long long id)
{
	unsigned int key = id%cap;
	
	struct cdUCI *pUci = chi_find_id(id);
	if (pUci != NULL)
	{
		pUci->uid = 0;
		delete (cdUCB*)(pUci->pUCB);
	}
	else
		return 0;

	return 1;
}


