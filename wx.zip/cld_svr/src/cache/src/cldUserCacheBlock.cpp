#include "cldUserCacheBlock.h"
#include <stdlib.h>
#include <stdio.h>

#define CUB_SCORE_ERR_FLAG	-1

cdUCB::cdUCB(void)
{
	uid = 0;
	lastLvl = 0;
	paidLevel = 0;

	for (int i = 0; i < UCB_MAX_ITEM; i++)
	{
		timeStramp[i] = 0;
		scores[i] = CUB_SCORE_ERR_FLAG;
	}

	frdInfo.count = 0;
	frdInfo.next = NULL;
	
	for (int i = 0; i < MAX_FRIENDS_COUNT; i++)
	{
		frdInfo.frdUid[i] = 0;
	}	
}

cdUCB::cdUCB(long long id)
{
	lastLvl = 0;
	for (int i = 0; i < UCB_MAX_ITEM; i++)
	{
		timeStramp[i] = 0;
		scores[i] = CUB_SCORE_ERR_FLAG;
	}

	frdInfo.count = 0;
	frdInfo.next = NULL;

	for (int i = 0; i < MAX_FRIENDS_COUNT; i++)
	{
		frdInfo.frdUid[i] = 0;
	}	
	
	uid = id;
}

cdUCB::~cdUCB()
{
	struct frdList *pCur, *pNext;
	pCur = frdInfo.next;
	pNext = frdInfo.next;

	while (pCur != NULL)
	{
		pNext = pCur->next;
		free(pCur);
		pCur = pNext;
	}
}

cdUCB* cdUCB::create(long long id)
{
	cdUCB* pUCB = new cdUCB(id);
	if (pUCB == NULL)
	{
		printf("cdUCB malloc failse");
	}
	
	return pUCB;
}

void cdUCB::setID(long long id)
{
	uid = id;
}

long long cdUCB::getUID(void)
{
	return uid;
}

int cdUCB::updateScore(int lvl, int score)
{
	if (lvl < 1 || lvl > UCB_MAX_ITEM)
	{
		printf("updateScore(), out of range, faile!!!");
		return -1;
	}

	if (lvl > lastLvl)
		lastLvl = lvl;

	int ret = 0;
	if (scores[lvl-1] == CUB_SCORE_ERR_FLAG)
		ret = 1;
	else if (score <= scores[lvl-1])
	{
		ret = -1;
	}
	else
		scores[lvl-1] = score;

	return ret;
}

int cdUCB::getScoreOfLevel(int level)
{
	if (level < 1 || level > UCB_MAX_ITEM)
	{
		printf("getScoreOfLevel(), fails, out of range!!");
		return -1;
	}

	return scores[level-1];
}

int cdUCB::getMaxLevel(void)
{
	return lastLvl;
}


int cdUCB::getFirstLackLevel(void)
{	
	int i;
	for (i = 0; i < lastLvl; i++)
		if (scores[i] == CUB_SCORE_ERR_FLAG)
			break;

	return (lastLvl-i)?(i+1):lastLvl;
}

int cdUCB::updatePaidLevel(int level)
{
	if (level > paidLevel)
		paidLevel = level;
	return paidLevel;
}

int cdUCB::getPaidLevel(void)
{
	return paidLevel;
}

int cdUCB::setFriendsList(long long *list, int cnt)
{
	if (list == NULL || cnt < 1)
	{
		printf("setFriendsList() fails, out of range or list is NULL");
		return 0;
	}

	int amount = cnt/MAX_FRIENDS_COUNT;
	int cntLoop = cnt>MAX_FRIENDS_COUNT?MAX_FRIENDS_COUNT:cnt;

	frdInfo.count = cnt;
	for (int i = 0; i < cntLoop; i++)
		frdInfo.frdUid[i] = list[i];

	struct frdList *pCur = &frdInfo;	
	int idxOffset = 1;
//	amount --;
	cnt -= MAX_FRIENDS_COUNT;
	while (amount > 0)
	{
		cntLoop = cnt>MAX_FRIENDS_COUNT?MAX_FRIENDS_COUNT:cnt;
		struct frdList *pNext = (struct frdList*)malloc(sizeof(struct frdList));
		pNext->count = cntLoop;
		pNext->next = NULL;
		for (int i = 0; i < cntLoop; i++)
		{	
			pNext->frdUid[i] = list[idxOffset*MAX_FRIENDS_COUNT+i];
		}
		pCur->next = pNext;
		pCur = pNext;
		
		idxOffset ++;
		amount --;
		cnt -= MAX_FRIENDS_COUNT;	
	}
	
	return cnt;
}

int cdUCB::addOneFriend(long long id)
{
	int ret = 0;
	struct frdList *pPre = &frdInfo;
	struct frdList *pNext;// = pPre->next;
	do
	{
		int cnt = (pPre->count >= MAX_FRIENDS_COUNT)?MAX_FRIENDS_COUNT:pPre->count;
		for (int i = 0; i < cnt; i++)
		{
			if (id == pPre->frdUid[i])
				goto UAF_EXIT;
		}
		pNext = pPre->next;
	}while (pNext != NULL);
	
	if (pPre->count >= MAX_FRIENDS_COUNT)
	{
		struct frdList *pAdd = (struct frdList*)malloc(sizeof(struct frdList));
		if (pAdd == NULL)
			return -1;
		pAdd->count = 1;
		pAdd->frdUid[0] = id;

		pPre->next = pAdd;
	}
	else
	{
		pPre->frdUid[pPre->count++] = id;
	}
	if (pPre != &frdInfo)
		frdInfo.count ++;
	ret = 1;
UAF_EXIT:
	return ret;
}

int cdUCB::removeOneFriend(long long id)
{
	struct frdList *pCur = &frdInfo;
	struct frdList *pNext;
	int i;
	do
	{
		int cnt = (pCur->count>MAX_FRIENDS_COUNT)?MAX_FRIENDS_COUNT:pCur->count;
		for (i = 0; i < cnt; i++)
		{
			if (pCur->frdUid[i] == id)
				goto rfExit;
		}
		pNext = pCur->next;
	}while (pNext != NULL);
	if (pNext == NULL)
		return 0;
/*rfExit:
	struct frdList *pLast = pPre;
	while (pLast->next != NULL)
	{
		pLast = pLast->next;
	}
	pPre->frdUid[i] = pLast->frdUid[pLast->count-1];
	pLast->count --;
	 
	

	struct frdList *pCur = &frdInfo;

	int i = 0;
	while (pCur != NULL)
	{
		int cnt = pCur->count>MAX_FRIENDS_COUNT?MAX_FRIENDS_COUNT:pCur->count;
		for (i = 0; i < cnt; i++)
		{
			if (pCur->frdUid[i] == id)
				goto rfExit;
		}
	}
	if (pCur == NULL)
		return -1;
*/
rfExit:
	struct frdList *pLast = &frdInfo;
	struct frdList *pPre = NULL;
	while (pLast->next != NULL)	
	{
		pPre = pLast;
		pLast = pLast->next;
	}
	pCur->frdUid[i] = pLast->frdUid[pLast->count-1];
	pLast->count --;
	if (pPre != NULL && pLast->count == 0)
	{
		pPre->next = NULL;
		free(pLast);
	}
	if (pPre != NULL)
		frdInfo.count --;

	return 1;	
}

int cdUCB::getFriendCount(void)
{
	return frdInfo.count;
}

int cdUCB::getFriendsList(long long *pList)
{
	if (pList == NULL || frdInfo.count <= 0)
		return 0;

	int off = 0;
	struct frdList *pCur = &frdInfo;
	while (pCur != NULL)
	{
		int cnt = pCur->count>=	MAX_FRIENDS_COUNT?MAX_FRIENDS_COUNT:pCur->count;
		for (int i = 0; i < cnt; i++)
			pList[off+i] = pCur->frdUid[i];
		off += cnt;
		pCur = pCur->next;		
	}
	
	return frdInfo.count;
}

struct frdList* cdUCB::getFriendList(void)
{
	return &frdInfo;
}

void cdUCB::dumpInfo(void)
{
	printf("---ucb info---\n");
	printf("id:%d\n", uid);
	printf("score cnt:%d, list:", lastLvl);
	for (int i = 0; i < lastLvl; i++)
		printf("%d,  ", scores[i]);
	printf("\n");
	printf("friends count:%d, list:", frdInfo.count);
	struct frdList *pFrd = &frdInfo;
	while (pFrd != NULL)
	{
		int cnt = pFrd->count>MAX_FRIENDS_COUNT?MAX_FRIENDS_COUNT:pFrd->count;

		for (int i = 0; i < cnt; i++)
			printf("%d,  ", pFrd->frdUid[i]);
		printf("||");
		pFrd = pFrd->next;
	}	
	printf("\n---end ucb---\n");	
}
