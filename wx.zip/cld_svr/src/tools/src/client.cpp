#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <netinet/tcp.h>
#include <time.h>
#include <fcntl.h>


#include "cldLogger.h"
#include "net_cmddef.h"
#include "net_ctrl.h"
#include "cldDbAdaptor.h"


static int cFlag = 0;
#if (CLDTARGET == 1)
static int startLvl = 1;
#endif

////////////////////////////////////
struct cld_id
{
	long long uid;
	int score;
	int count;
	long long *frdlist;
//	int *scorelist;
};

cld_id cldid;
////////////////////////////////////
#define MAXLINE 80
int port = 3344;
net_pack g_net_pack; 
net_peer g_net_peer; 

enum TMP_ERROR_CODE
{
    ERR_CODE_NONE = 0, 
    ERR_CODE_WAIT_REPLY, 
    ERR_PEER_CLOSED, 
}; 

int wait_for_reply_net_pack(net_pack * reply_pack)
{
    unsigned int read_len = read(g_net_peer.conn_fd, &g_net_pack, sizeof(net_pack));
    if (read_len == 0) return ERR_PEER_CLOSED; 
    return 0; 
}


int handle_command(char * cmd_line)
{
    if (strncmp(cmd_line, "connect", 7) == 0)
    {
#if (CLDTARGET == 1)
	if (cFlag == 1)
	{
		cLog::shareLog()->logger(Mod_NET, Lvl_Error, "connect delay over time");
		return 1; 
	}
#endif
	long long user_id = cldid.uid;
        // 登录 
        net_pack_init(&g_net_pack, NET_CMD_CONNECT); 
        net_pack_connect * conn_pack = (net_pack_connect *)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_connect)); 
        if (!conn_pack) return 0; 
        conn_pack->user_id = user_id;
#if (CLDTARGET == 1)	 
       	cFlag = 1; 
#endif
      	printf("connect request command, id:%lld\n", conn_pack->user_id); 
        (void)net_send_pack(&g_net_peer, &g_net_pack); 
	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, ">>CMD_CONNECT");
        int ret = wait_for_reply_net_pack(&g_net_pack); 
        if (g_net_pack.header.cmd == NET_CMD_CONNECT)
        {

    		unsigned int pack_offset = net_pack_get_org_offset(); 
            net_pack_err *msg;
            int ret = net_pack_get_block(&g_net_pack, pack_offset, (void**)&msg, sizeof(net_pack_err)); 
            if (ret < 0) return 1; 
		cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "<<CMD_CONNECT ack");
#if (CLDTARGET == 1)
		cFlag = 0;
#endif
            printf("\nConnect successfully, ack:%d\n", msg->err_code); 
            return 0; 
        }
        return 0; 
    }
    else if (strncmp(cmd_line, "message ", 8) == 0)
    {
        char * msg_str = &cmd_line[8]; 
        net_pack_init(&g_net_pack, NET_CMD_MESSAGE); 
        net_pack_message * msg_pack = (net_pack_message *)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_message)); 
        if (!msg_pack) return 0; 
        msg_pack->str_len = strlen(msg_str); 
        memcpy(msg_pack->message, msg_str, msg_pack->str_len); 
        msg_pack->message[msg_pack->str_len] = 0; 
        
        (void)net_send_pack(&g_net_peer, &g_net_pack); 
    }
	else if (strncmp(cmd_line, "frdlist", 7) == 0)
	{
		int fcnt = cldid.count;
		net_pack_init(&g_net_pack, NET_CMD_FRIENDSHIP);
		net_pack_friend_list *msg_pack = (net_pack_friend_list*)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_friend_list)+fcnt*sizeof(long long));
		if (! msg_pack)
			return 0;
		msg_pack->user_id = cldid.uid;
		msg_pack->friend_num = fcnt;
	
		if (fcnt > 0)
		{
		long long *pCur = (long long*)((char*)msg_pack+sizeof(net_pack_friend_list));
		for (int i = 0; i < fcnt; i++)
			*pCur++ = cldid.frdlist[i];
		}
//		printf("flist ,id:%lld, num:%d\n", msg_pack->user_id, msg_pack->friend_num);
//		pCur = (long long*)((char*)msg_pack+sizeof(net_pack_friend_list));
//		for (int i = 0; i < fcnt; i++)
//			printf("f:%d, id:%lld\n", i, *pCur++);	
	//	net_adjust_pack_message(msg_pack);
		printf("send fried list command\n");
       cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "frdlist %s", net_pack_parse_format(&g_net_pack)); 
		(void)net_send_pack(&g_net_peer, &g_net_pack);
	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, ">>CMD_FRIENDSHIP");	
        int ret = wait_for_reply_net_pack(&g_net_pack); 
        if (g_net_pack.header.cmd == NET_CMD_FRIENDSHIP)
        {
	
    		unsigned int pack_offset = net_pack_get_org_offset(); 
		unsigned int temp = pack_offset;
            net_pack_ack_friend_list *msg;
            int ret = net_pack_get_block(&g_net_pack, pack_offset, (void**)&msg, sizeof(net_pack_ack_friend_list)); 
            if (ret < 0) return 1; 
            cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "<<CMD_FRIENDSHIP ack, ret:%d", msg->num);
		printf("\nrec friendship ack, count:%d\n", msg->num); 
       cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "ack %s", net_pack_parse_format(&g_net_pack)); 
		if (msg->num == 0)
			return 1;
		pack_offset = temp;
		int cnt = msg->num;
		if (cnt <= 0)
			return 1;
             ret = net_pack_get_block(&g_net_pack, pack_offset, (void**)&msg, sizeof(net_pack_ack_friend_list)+cnt*sizeof(long long));
		if (ret < 0)
			return 1;
		long long *list = (long long*)((char*)msg+sizeof(net_pack_ack_friend_list));
//		for (int i = 0; i < cnt; i++)
//			printf("vf, %d: %lld\n", i, list[i]); 
            return 0; 
        }
	}	
    else if (strncmp(cmd_line, "frdrank", 7) == 0)
    {
        net_pack_init(&g_net_pack, NET_CMD_FRIEND_RANK); 
        net_pack_request_rank * msg_pack = (net_pack_request_rank *)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_request_rank)); 
        if (!msg_pack) return 0; 
	msg_pack->user_id = cldid.uid; 
      	msg_pack->level_num = 1;
	msg_pack->start = 1;
	msg_pack->num = 10;

	printf("frdrank, id:%lld, level:%d, start:%d, end:%d\n", msg_pack->user_id, msg_pack->level_num, msg_pack->start, msg_pack->num); 
//        net_adjust_pack_message(msg_pack); 
	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "frdrank send pack:%s", net_pack_parse_format(&g_net_pack));
        (void)net_send_pack(&g_net_peer, &g_net_pack); 
   	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, ">>CMD_FRIEND_RANK");
	printf("send friend rank command\n");
        int ret = wait_for_reply_net_pack(&g_net_pack); 
        if (g_net_pack.header.cmd == NET_CMD_FRIEND_RANK)
        {	 
    		unsigned int pack_offset = net_pack_get_org_offset(); 
            net_pack_ack_rank *ra;
		unsigned int temp = pack_offset;
            int ret = net_pack_get_block(&g_net_pack, pack_offset, (void**)&ra, sizeof(net_pack_ack_rank)); 
		printf("recv rank ack, ret:%d!!\n", ret);	
            if (ret < 0)
		 return 1; 
	 
       cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "frdrank %s", net_pack_parse_format(&g_net_pack)); 
		int cnt = ra->num;
		printf("\nid:%lld, friend rank ack, num:%d, cldid.count:%d\n", cldid.uid, cnt, cldid.count); 
		if (cnt <= 0)
			return 0;

		pack_offset = temp;
             ret = net_pack_get_block(&g_net_pack, pack_offset, (void**)&ra, sizeof(net_pack_ack_rank)+cnt*sizeof(rank_info)); 
		if (ret < 0)
		{
			return 1;
		}
		printf("second get rank ack pack ok!!\n");
		cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "<<CMD_FRIEND_RANK ack start:%d, nuj:%d, isEnd:%d", ra->start, ra->num, ra->is_end);
/*		struct rank_info *pp = (struct rank_info*)((char*)ra+sizeof(net_pack_ack_rank));
		struct rank_info *pcur = pp;
		for (int i = 0; i < ra->num; i++)
		{
			int j;
		
			if ((pcur->friend_id == cldid.uid) && (pcur->score == cldid.score))
				continue;
			for (j = 0; j < cldid.count; j++)
			{
				if ((pcur->friend_id == cldid.frdlist[j]) && (pcur->score == cldid.scorelist[j]))
					break;
			}

			if (j == cldid.count)
				cLog::shareLog()->logger(Mod_NET, Lvl_Error, "frd score not match!");
			pcur ++;
		}
*/
/*		for (int i = 0; i < ra->num; i++)
		{
			cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "frd:%lld, score:%d", pp->friend_id, pp->score);
			pp++;
		}
*/
//		return 0; 
        }
    }
	else if (strncmp(cmd_line, "reqheart", 8) == 0)
	{
//	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "request heart!");
        net_pack_init(&g_net_pack, NET_CMD_REQUEST_HEART); 
        net_pack_user * msg_pack = (net_pack_user *)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_user)); 
        if (!msg_pack) return 0; 
	msg_pack->user_id = cldid.uid;
//	printf("\nrequest heart msg, id:%lld\n", msg_pack->user_id);

	(void)net_send_pack(&g_net_peer, &g_net_pack);
	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, ">>CMD_REQUEST_HEART");

        int ret = wait_for_reply_net_pack(&g_net_pack); 
        if (g_net_pack.header.cmd == NET_CMD_REQUEST_HEART)
	{
		cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "<<CMD_REQUEST_HEART ack!");	
	}
	}
	else if (strncmp(cmd_line, "giftheart", 9) == 0)
	{
		if (cldid.count <= 0)
			return 1;
        net_pack_init(&g_net_pack, NET_CMD_GIFT_HEART); 
        net_pack_friendship * msg_pack = (net_pack_friendship *)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_friendship)); 
        if (!msg_pack) return 0; 
	msg_pack->user_id = cldid.uid;
	msg_pack->friend_id = cldid.frdlist[0];
//	printf("\ngift heart msg, id:%lld, friend:%lld\n", msg_pack->user_id, msg_pack->friend_id);

	(void)net_send_pack(&g_net_peer, &g_net_pack);
	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, ">>CMD_GIFT_HEART");
        int ret = wait_for_reply_net_pack(&g_net_pack); 
        if (g_net_pack.header.cmd == NET_CMD_GIFT_HEART)
	{
		cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "<<CMD_GIFT_HEART ack");
	}
	}
	else if (strncmp(cmd_line, "reqmsg", 6) == 0)
	{
		net_pack_init(&g_net_pack, NET_CMD_QUERY_HEART_MSG);
		net_pack_user *msg = (net_pack_user *)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_user));
		if (! msg)
			return 0;
		msg->user_id = cldid.uid;
		printf("\nreq msg id:%lld\n", msg->user_id);
		(void)net_send_pack(&g_net_peer, &g_net_pack);
		cLog::shareLog()->logger(Mod_NET, Lvl_Debug, ">>CMD_QUERY_HEART_MSG");	
	        int ret = wait_for_reply_net_pack(&g_net_pack); 
	        if (g_net_pack.header.cmd = NET_CMD_QUERY_HEART_MSG)
		{
    			unsigned int pack_offset = net_pack_get_org_offset(); 
            		int temp = pack_offset;
			net_pack_heart_msg_head *msg;
        	    	int ret = net_pack_get_block(&g_net_pack, pack_offset, (void**)&msg, sizeof(net_pack_heart_msg_head));
			int cnt = msg->num;
			printf("recv reqmsg ack!!, msg cnt:%d\n", cnt);
			cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "<<CMD_QUEREY_HEART_MSG ack, msg cnt:%d", cnt);	
			pack_offset = temp;
			ret = net_pack_get_block(&g_net_pack, pack_offset, (void**)&msg, sizeof(net_pack_heart_msg_head)+cnt*sizeof(heart_msg_info));
			heart_msg_info *p = (heart_msg_info*)((char*)msg+sizeof(net_pack_heart_msg_head));
			for (int i = 0; i < cnt; i++)
			{
				cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "friend:%lld give me msg, type:%d", p->friend_id, p->type);
//				printf("\nmsg, type:%d, friend_id:%lld\n", p->type, p->friend_id);
				p++;
			} 
            		if (ret < 0)
				 return 1; 
		}
	}
	else if (strncmp(cmd_line, "fetchscore", 10) == 0)
	{
		net_pack_init(&g_net_pack, NET_CMD_FETCH_SCORE);
		net_pack_request_fetch_score *msg = (net_pack_request_fetch_score*)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_request_fetch_score));
		if (!msg)
			return 0;
		msg->user_id = cldid.uid;
		msg->num = 10;
		msg->start_level = 1;

		(void)net_send_pack(&g_net_peer, &g_net_pack);
		printf("send NET FETCH SCORE cmd, start:%d, num:%d\n", msg->start_level, msg->num);
		int ret = wait_for_reply_net_pack(&g_net_pack);
		if (g_net_pack.header.cmd = NET_CMD_FETCH_SCORE)
		{
    			unsigned int pack_offset = net_pack_get_org_offset(); 
            		int temp = pack_offset;
			net_pack_ack_fetch_score *ack;
        	    	int ret = net_pack_get_block(&g_net_pack, pack_offset, (void**)&ack, sizeof(net_pack_ack_fetch_score));
			if (ret < 0)
				return 1;
			int cnt = ack->num;
			printf("recv CMD_FETCH_SCORE ack, num:%d\n", cnt);
			pack_offset = temp;
			ret = net_pack_get_block(&g_net_pack, pack_offset, (void**)&ack, sizeof(net_pack_ack_fetch_score)+cnt*sizeof(int));
			int *pl = (int*)((char*)ack+sizeof(net_pack_ack_fetch_score));
			for (int i = 0; i < cnt; i++)
			{
				printf("l:%d, score:%d\n", ack->start_level+i, *pl);
				pl++;
			}	
		} 
	}
   else if (strncmp(cmd_line, "sync", 4) == 0)
   {
		
        net_pack_init(&g_net_pack, NET_CMD_SYNC); 
	net_pack_user * msg = (net_pack_user *)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_user)); 
        if (!msg) return 0; 
	msg->user_id = cldid.uid;
	
	(void)net_send_pack(&g_net_peer, &g_net_pack);
	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "send sync command");
	
        int ret = wait_for_reply_net_pack(&g_net_pack); 
        if (g_net_pack.header.cmd == NET_CMD_SYNC)
	{
		cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "received sync ack!");
	} 
    }
	else if (strncmp(cmd_line, "score", 5) == 0)
	{
#if (CLDTARGET == 2)
	if (cFlag == 1)
	{
		cLog::shareLog()->logger(Mod_NET, Lvl_Error, "received sync ack!");
		return 1;	
	}
#endif
#define CLD_ONCE_SCORE_CNT	5
        net_pack_init(&g_net_pack, NET_CMD_UPDATE_SCORE); 
	net_pack_update_score * msg = (net_pack_update_score *)net_pack_alloc_block(&g_net_pack, sizeof(net_pack_update_score)+CLD_ONCE_SCORE_CNT*sizeof(int)); 
        if (!msg) return 0; 
	msg->user_id = cldid.uid;
#if (CLDTARGET == 2)
	msg->start_level = startLv;
#else
	msg->start_level = 1;
#endif
	msg->num = CLD_ONCE_SCORE_CNT;
	int *pScore = (int*)((char*)msg+sizeof(net_pack_update_score));
	for (int i = 0; i < CLD_ONCE_SCORE_CNT; i++)
	{
		pScore[i] = cldid.score+i*10;
	}
	
	(void)net_send_pack(&g_net_peer, &g_net_pack);
	cLog::shareLog()->logger(Mod_NET, Lvl_Debug, ">>CMD_UPDATE_SCORE start_level:%d num:%d\n", msg->start_level, msg->num);
//	printf("send score command\n");	
        int ret = wait_for_reply_net_pack(&g_net_pack); 
        if (g_net_pack.header.cmd == NET_CMD_UPDATE_SCORE)
	{
//		printf("received update score ack");
		cLog::shareLog()->logger(Mod_NET, Lvl_Debug, "<<CMD_UPDATE_SCORE ack!");
	} 
		
	}
    return 0; 
}

int handle_reply_net_pack(net_pack * reply_pack)
{
    switch (reply_pack->header.cmd)
    {
        case 0:
//            printf("connect successfully\n"); 
            break; 
  //	case NET_CMD_FRIEND_RANK:
//		printf("friend rank request ack!\n");
//		break;
  //    	case NET_CMD_REQUEST_HEART:
//		printf("!!!request heart, id:\n");
//		break;
//	case NET_CMD_GIFT_HEART:
//		printf("###gift heart, id:\n");
//		break;
	default: 
            break; 
    }
    return 0; 
}


int main(int argc, char *argv[])
{
	//----- g id init -----
	if (argc < 2)
	{
		cldid.uid = 3184871973;
		cldid.count = 0;
		cldid.frdlist = NULL;
//		cldid.scorelist = NULL;
	}
	else
	{
		int k = argc-3;
		if (k > 0)
		{
		cldid.frdlist = (long long*)malloc(k*sizeof(long long));
//		cldid.scorelist = (int*)malloc(k*sizeof(int));
			for (int i = 0; i < k; i++)
				cldid.frdlist[i] = atoll(argv[i+2]);
			cldid.count = k;
		}
		else
			cldid.count = 0;
		cldid.uid = atoll(argv[1]);

		cldid.score = atoi(argv[argc-1]);
	}

	char nbuf[16] = {0};
	sprintf(nbuf, "Clog-%lld", cldid.uid);
//	cld_logger_init(nbuf);
	cLog::shareLog()->init(nbuf);

	cLog::shareLog()->logger(Mod_SYS, Lvl_Debug, "uid:%lld, score:%d, frdCount:%d", cldid.uid, cldid.score, cldid.count);
	for (int i = 0; i < cldid.count; i++)
	{
		cLog::shareLog()->logger(Mod_SYS, Lvl_Debug, "fid:%lld", cldid.frdlist[i]);
	}


//////////////////////////////////////////////////////////////////	
  struct sockaddr_in pin;
  int conn_fd; 
  char buf[MAXLINE];
  char str[MAXLINE];
  int n;
  

////////////////////////////////////////////////
  signal(SIGPIPE,SIG_IGN);

  bzero(&pin, sizeof(pin));
  pin.sin_family = AF_INET;
  inet_pton(AF_INET, "127.0.0.1", &pin.sin_addr);
  pin.sin_port = htons(port);
  
  conn_fd = socket(AF_INET, SOCK_STREAM, 0);
  n=connect(conn_fd, (sockaddr*)&pin, sizeof(pin));
  if (-1 == n)
  {
     perror("call connect");
     exit(1);
  }
  
  g_net_peer.conn_fd = conn_fd; 
  
	printf("client: %lld start!!!\n", cldid.uid);
//  printf("******************************\n"); 
//  printf("*  Welcome to bubble world!  *\n"); 
//  printf("******************************\n"); 
  printf(">"); 
  
  // 数据包马上发送 
  int on = 1; 
  
  setsockopt (conn_fd, SOL_TCP, TCP_NODELAY, &on, sizeof (on));

#if (CLDTARGET == 0)
#if 1
	srand(cldid.uid);
	
	unsigned int gCounter = 1;
	int conCnt = 100;
	int frdCnt = conCnt+unsigned(rand())%500;
	int scoreCnt = frdCnt+unsigned(rand())%500;
	int reqhrt = scoreCnt+unsigned(rand())%500;
	int gifthrt = reqhrt+unsigned(rand())%500;
	int rankCnt = gifthrt+unsigned(rand())%500;
	int ftScore = rankCnt+unsigned(rand())%500;
	int synt = 500+unsigned(rand())%500;	

	int msgCnt = 0;
	while (1)
	{
		usleep(10000);
		if ((gCounter > ftScore) && ((gCounter%synt) == 0))
		{
			handle_command("reqmsg");
			msgCnt ++;
			if (msgCnt > 10)
				gCounter = 101;
		}

		if (gCounter == conCnt)
		{
			handle_command("connect");
		}
		else if(gCounter == frdCnt)
		{
			handle_command("frdlist");
		}
		else if (gCounter == scoreCnt)
		{
			handle_command("score");
		}
		else if (gCounter == reqhrt)
		{
			handle_command("reqheart");
		}
		else if (gCounter == gifthrt)
		{
			handle_command("giftheart");
		}
		else if (gCounter == rankCnt)
		{
			handle_command("frdrank");
		}
		else if (gCounter == ftScore)
		{
			handle_command("fetchscore");
		}
		
		gCounter ++;
	}
#else
	while(NULL != fgets(str,MAXLINE, stdin))
  {
    (void)handle_command(str); 
    
    printf(">"); 
  }
#endif

#elif (CLDTARGET == 1)
//	srand(cldid.uid);
	unsigned int gCounter = 1;
	
	while (1)
	{
		usleep(10000);
		if ((gCounter %300) == 0)	
		{
			handle_command("connect");
		}
	
		gCounter ++;
	}
#elif (CLDTARGET == 2)
	unsigned int gCounter = 1;
	
	while (1)
	{
		usleep(10000);
		if ((gCounter %500) == 0)	
		{
			handle_command("score");
			handle_command("fetch");
			cldid.score += 10;
			startLvl += 4;
		}
	
		gCounter ++;
	}

#elif (CLDTARGET == 3)
	unsigned int gCounter = 1;
	
	while (1)
	{
		usleep(10000);
		if ((gCounter %300) == 0)	
		{
			handle_command("connect");
		}
	
		gCounter ++;
	}

#elif (CLDTARGET == 4)
	unsigned int gCounter = 1;
	
	while (1)
	{
		usleep(10000);
		if ((gCounter %300) == 0)	
		{
			handle_command("connect");
		}
	
		gCounter ++;
	}

#elif (CLDTARGET == 5)
	unsigned int gCounter = 1;
	
	while (1)
	{
		usleep(10000);
		if ((gCounter %300) == 0)	
		{
			handle_command("connect");
		}
	
		gCounter ++;
	}

#else 

#endif

	cLog::shareLog()->logger(Mod_SYS, Lvl_Critical, "system terminate!!!");

close(conn_fd);
	//cld_logger_close();
  return 0;
}

