#ifndef __SERVER_H__
#define __SERVER_H__

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <stdlib.h>
#include <signal.h>

#define SEVER_IDLE_SLEEP_TIME  50000

void * thread_server_listener(void * data); 
void * thread_server_receiver(void * data); 
void * thread_server_pack_handler(void * data); 

#endif // __SERVER_H__


