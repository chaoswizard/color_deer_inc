#ifndef _CLD_DB_QUEUE_H_
#define _CLD_DB_QUEUE_H_

enum dbOptType
{
	DB_ReqhrtInsert = 0,
	DB_GifthrtInsert,
	DB_CnfhrtInsert,
	
	DB_ScoreInsert,	//
	DB_ScoreUpdate,
	DB_FrdInsert,
	DB_FrdDelete,

	DB_Paidlevel
};

struct dbMsg
{
	dbOptType type;
	long timestamp;

	long long id;
	union
	{
		struct
		{
			int level;
			int score;
		}sdata;
		long long fid;
	};
};

int db_queue_init(void);
int db_queue_push(struct dbMsg *msg);
struct dbMsg* db_queue_pop(void);


#endif

