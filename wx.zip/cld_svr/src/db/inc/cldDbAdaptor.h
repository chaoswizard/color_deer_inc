#ifndef _CLD_DB_ADAPTOR_H_
#define _CLD_DB_ADAPTOR_H_

struct dbRankInfo
{
	long long id;
	int score;
};

struct dbHrtmsg
{
	int type;
	long time;
	long long fid;
};

int db_connect(void);

//int db_insert_id(long long id);
int db_get_userlist(long long *idlist, int offset, int count);
int db_get_score_level(long long id, int level);
int db_get_friendship(long long id, long long *list, int offset, int count);
int db_insert_score(long long id, int level, int score);
int db_update_score(long long id, int level, int score);
int db_update_insert_score(long long id, int level, int score);

int db_insert_friendship(long long id, long long frdid);
int db_delete_friendship(long long id, long long frdid);
int db_find_id(long long id);

int db_insert_hrtmsg(long long id, struct dbHrtmsg *msg);
int db_delete_hrtmsg(long long id);
int db_get_hrtmsg_list(long long id, struct dbHrtmsg *mList);
 
int db_get_all_rank_level(struct dbRankInfo *list, int level, int offset, int count);

int db_insert_paidlevel(long long id, int level);
int db_get_paidlevle(long long id);

void db_close(void);

void db_info(void);


#endif

