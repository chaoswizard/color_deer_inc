#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>

#include "cldDbQueue.h"

#define CDQ_MAX_SIZE		128

class dbQueue
{
	int size;
	int head;
	int tail;
	struct dbMsg *dq;
	pthread_rwlock_t lock;

public:
	dbQueue();
	~dbQueue();
	
	int cdq_push(struct dbMsg *msg);
	struct dbMsg* cdq_pop(void);
};

static class dbQueue *g_cdq = NULL;

dbQueue::dbQueue()
{
	pthread_rwlock_init(&lock, NULL);

	size = CDQ_MAX_SIZE;
	head = 0;
	tail = 0;

	dq = (struct dbMsg*)malloc(size*sizeof(struct dbMsg));
	if (dq == NULL)
		printf("dbQueue malloc failed!!!\n");

	
}

dbQueue::~dbQueue()
{
	if (dq != NULL)
		free(dq);

	pthread_rwlock_destroy(&lock);
}

int dbQueue::cdq_push(struct dbMsg *msg)
{
	if (dq == NULL || msg == NULL)
		return 0;

	if ((head+1)%size == tail)
	{
		pthread_rwlock_wrlock(&lock);

		struct dbMsg *new_dq = (struct dbMsg*)malloc(size*2*sizeof(struct dbMsg));
		for (int i = 0; i < size-1; i++)
		{
			new_dq[i] = dq[(i+tail)%size];
		}

		free(dq);
		dq = new_dq;
		head = size-1;
		tail = 0;
		size *= 2;

		pthread_rwlock_unlock(&lock);
	}

	struct dbMsg *slot = &dq[head];
	memcpy(slot, msg, sizeof(struct dbMsg));

	head = (head+1)%size;

	return 1;
}

struct dbMsg* dbQueue::cdq_pop(void)
{
	if ((dq == NULL) || (tail == head))
		return NULL;

	pthread_rwlock_rdlock(&lock);

	struct dbMsg *slot = &dq[tail];
	tail = (tail+1)%size;

	pthread_rwlock_unlock(&lock);

	return slot;
}

int db_queue_init(void)
{
	if (g_cdq == NULL)
	{
		g_cdq = new dbQueue();
		if (g_cdq == NULL)
			return 0;
	}

	return 1;
}

int db_queue_push(struct dbMsg *msg)
{
	if ((g_cdq == NULL) || (msg == NULL))
		return 0;

	return g_cdq->cdq_push(msg);
}

struct dbMsg* db_queue_pop(void)
{
	if (g_cdq == NULL)
		return NULL;

	return g_cdq->cdq_pop();
}


