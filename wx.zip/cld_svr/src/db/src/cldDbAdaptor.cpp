#include <stdio.h>
#include <stdlib.h>
#include <mysql.h>
#include <string.h>
#include <pthread.h>

#include "cldDbAdaptor.h"
#include "cldLogger.h"


#define CLD_DB_USER		"cldeer"
#define CLD_DB_PW		"cldeer"

#define CLD_DB_NAME					"bubble"
#define CLD_DB_TB_SCORE				"bubble_score"
#define CLD_DB_TB_FRIENDSHIP		"bubble_friendship"

#define CLD_DB_USERID				"user_id"
#define CLD_DB_LEVEL				"level"
#define CLD_DB_SCORE				"score"
#define CLD_DB_FRIEND				"friend_id"

static MYSQL *bubble_db = NULL;
static pthread_mutex_t dbLock;

int db_connect(void)
{
	printf("mysql client version: %s\n", mysql_get_client_info());

	bubble_db = mysql_init(NULL);
	if (! bubble_db)
	{
		printf("mysql init failed!\n");
		return -1;
	}

	bubble_db = mysql_real_connect(bubble_db, "localhost", CLD_DB_USER, CLD_DB_PW, CLD_DB_NAME, 0, NULL, 0);
	if (bubble_db == NULL)
	{
		printf("mysql connection failed\n");
		return -1;
	}

	pthread_mutex_init(&dbLock, NULL);
	
	return 1;
}

int db_find_id(long long id)
{
	int ret = 0;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "SELECT user_id FROM bubble_score WHERE user_id=%lld", id);

		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("find id query failed!\n");
			ret = 0;
			goto dfi_exit;
		}
		MYSQL_RES *res = mysql_store_result(bubble_db);
		if (res == NULL)
		{
			printf("get user list no result\n");
			goto dfi_exit;
		}

		ret = mysql_num_rows(res);
		mysql_free_result(res);
	//	printf("db find cnt:%d\n", ret);	
	}
dfi_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}
/*
int db_insert_id(long long id)
{
	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "INSERT INTO bubble_friendship VALUES(%lld, 123)", id);

		int ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("inset id failed!!\n");
			return 0;
		}
		return 1;
	}
	return -1;
}
*/

int db_get_userlist(long long *idlist, int offset, int count)
{
	if (idlist == NULL || count <= 0 || offset < 0)
		return 0;

	int ret = 0;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "SELECT DISTINCT user_id FROM bubble_score LIMIT %d, %d", offset, count);
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("mysql get user list faile\n");
			ret = 0;
			goto dgl_exit;
		}
		MYSQL_RES *res = mysql_store_result(bubble_db);
		if (res == NULL)
		{
			printf("get user list no result\n");
			goto dgl_exit;
		}
		ret = mysql_num_rows(res);
		MYSQL_ROW row;
		for (int i = 0; i < ret; i++)
		{
			row = mysql_fetch_row(res);
			idlist[i] = atoll(row[0]);
		}
		
		mysql_free_result(res);
	}	
dgl_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}


int db_get_score_level(long long id, int level)
{
	if (level < 0)
		return -1;

	int ret = -1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "SELECT score FROM bubble_score WHERE user_id=%lld and level=%d", id, level);
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("get score failed\n");
			goto dsl_exit;
		}

		MYSQL_RES *res = mysql_store_result(bubble_db);
		if (res == NULL)
		{
			printf("get score result none\n");
			goto dsl_exit;
		}

		if (mysql_num_rows(res))
		{	
			MYSQL_ROW row = mysql_fetch_row(res);
			ret = atoi(row[0]); 
		}	

		mysql_free_result(res);
	}
dsl_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}


int db_get_friendship(long long id, long long *list, int offset, int count)
{
	if (list == NULL || count <= 0 || offset < 0)
		return 0;
	int ret;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "SELECT DISTINCT friend_id FROM bubble_friendship WHERE user_id=%lld LIMIT %d, %d", id, offset, count);

		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("friendship query failed\n");
			ret = -1;
			goto dgf_exit;
		}

		MYSQL_RES *res = mysql_store_result(bubble_db);
		if (res == NULL)
		{
			printf("get friendship none result\n");
			ret = 0;
			goto dgf_exit;
		}
		ret = mysql_num_rows(res);
		MYSQL_ROW row;
		for (int i = 0; i < ret; i++)
		{
			row = mysql_fetch_row(res);
			list[i] = atoll(row[0]);
		}

		mysql_free_result(res);
	}
dgf_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;

}

int db_update_score(long long id, int level, int score)
{
	int ret = 1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[256] = {0};
		sprintf(q, "UPDATE bubble_score SET score=%d WHERE user_id=%lld AND level=%d", score, id, level);
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("update score query failed!");
			ret = 0;
			goto dus_exit;
		}
	}
dus_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

int db_insert_score(long long id, int level, int score)
{
	int ret = 1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "INSERT INTO bubble_score VALUES(%lld, %d, %d)", id, level, score);
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("insert score failed!\n");
			ret = 0;
			goto dis_exit;
		}
		cLog::shareLog()->logger(Mod_DB, Lvl_Backup, "insert score %lld %d %d", id, level, score);
	}
	
dis_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

int db_update_insert_score(long long id, int level, int score)
{
	int ret = 1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "UPDATE bubble_score SET score=%d WHERE user_id=%lld AND level=%d", score, id, level);
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("update score query failed!");
			ret = 0;
			goto duis_exit;
		}
		ret = mysql_affected_rows(bubble_db);
		printf("affect ret:%d\n", ret);
		if (ret == 0)
		{
			memset(q, 0, 128);
			sprintf(q, "INSERT INTO bubble_score VALUES(%lld, %d, %d)", id, level, score);
			ret = mysql_query(bubble_db, q);
			if (ret)
			{
				printf("update and insert, insert failed!!");
				ret = 0;
				goto duis_exit;
			}
		}
	}
duis_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

int db_insert_friendship(long long id, long long frdid)
{
	int ret = 1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "INSERT INTO bubble_friendship VALUES(%lld, %lld)", id, frdid);
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("friendship table insert failed!\n");
			ret = 0;
			goto dif_exit;
		}

		cLog::shareLog()->logger(Mod_DB, Lvl_Backup, "insert friendship %lld %lld", id, frdid);
	}
dif_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

int db_delete_friendship(long long id, long long frdid)
{
	int ret = 1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "DELETE FROM bubble_friendship WHERE user_id=%lld AND friend_id=%lld", id, frdid);

		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("db friendship delete failed!\n");
			ret = -1;
			goto ddf_exit;
		}

		cLog::shareLog()->logger(Mod_DB, Lvl_Backup, "delete friendship %lld %lld", id, frdid);
	}
ddf_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

int db_insert_hrtmsg(long long id, struct dbHrtmsg *msg)
{
	if (msg == NULL)
		return 0;

	int ret = 1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "INSERT INTO bubble_heartmsg VALUES(%lld, %d, %lld, %lld)", id, msg->type, msg->fid, msg->time);
	
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("heartmsg table insert failed!\n");
			ret = 0;
			goto dih_exit;
		}

		cLog::shareLog()->logger(Mod_DB, Lvl_Backup, "insert heart msg %lld %d %lld", id, msg->type, msg->fid);
	}
dih_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

int db_delete_hrtmsg(long long id)
{
	int ret = 1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "DELETE FROM bubble_heartmsg WHERE user_id=%lld", id);

		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("db heart msg delete failed!\n");
			ret = -1;
			goto ddh_exit;
		}

		cLog::shareLog()->logger(Mod_DB, Lvl_Backup, "delete heart msg %lld", id);
	}
ddh_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

int db_get_hrtmsg_list(long long id, struct dbHrtmsg *mList)
{
	if (mList == NULL)
		return 0;

	int ret = 0;

	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "SELECT type,friend_id,time FROM bubble_heartmsg WHERE user_id=%lld", id);
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("get heart msg query failed, ret:%d, err:%s, errno:%d\n", ret, mysql_error(bubble_db), mysql_errno(bubble_db));
			ret = 0;
			goto dghl_exit;
		}

		MYSQL_RES *res = mysql_store_result(bubble_db);
		if (res == NULL)
		{
			printf("get hrtmsg result failed:%s [%s], errno:%d\n", mysql_error(bubble_db), q, mysql_errno(bubble_db));
			ret = 0;
			goto dghl_exit;
		}

		ret = mysql_num_rows(res);
		printf("hrtmsg ret cnt:%d\n", ret);
		MYSQL_ROW row;
		for (int i = 0; i < ret; i++)
		{
			row = mysql_fetch_row(res);
			mList[i].type = atoi(row[0]);
			mList[i].fid = atoll(row[1]);
			mList[i].time = atol(row[2]);
		}
		
		mysql_free_result(res);
	}
dghl_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

int db_get_all_rank_level(struct dbRankInfo *list, int level, int offset, int count)
{
	if (list == NULL || count <= 0)
		return 0;

	int ret = 1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "SELECT user_id, score FROM bubble_score WHERE level=%d ORDER BY score DESC LIMIT %d, %d", level, offset, count);
	
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			printf("friendship query failed\n");
			ret = -1;
			goto dgarl_exit;
	//		return -1;
		}

		MYSQL_RES *res = mysql_store_result(bubble_db);
		if (res == NULL)
		{
			printf("get friendship none result\n");
			ret = 0;
			goto dgarl_exit;
//			return 0;
		}
		ret = mysql_num_rows(res);
		MYSQL_ROW row;
		for (int i = 0; i < ret; i++)
		{
			row = mysql_fetch_row(res);
			list[i].id = atoll(row[0]);
			list[i].score = atoi(row[1]);
		}

		mysql_free_result(res);
	}
dgarl_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;	
}

int db_insert_paidlevel(long long id, int level)
{
	int ret = 1;

	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "INSERT INTO bubble_paidlevel VALUES(%lld, %d)", id, level);
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			ret = 0;
			goto dip_exit;
		}
	}

dip_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

int db_get_paidlevle(long long id)
{
	int ret = -1;
	pthread_mutex_lock(&dbLock);

	if (bubble_db)
	{
		char q[128] = {0};
		sprintf(q, "SELECT level FROM bubble_paidlevel WHERE user_id=%lld", id);
		ret = mysql_query(bubble_db, q);
		if (ret)
		{
			ret = -1;
			goto dgp_exit;
		}

		MYSQL_RES *res = mysql_store_result(bubble_db);
		if (res == NULL)
		{
			printf("get user list no result\n");
			goto dgp_exit;
		}
		ret = mysql_num_rows(res);
		if (ret == 0)
		{
			ret = -1;
			goto dgp_exit;
		}

		MYSQL_ROW row = mysql_fetch_row(res);
		ret = atoi(row[0]);
	
		mysql_free_result(res);
	}
dgp_exit:
	pthread_mutex_unlock(&dbLock);
	return ret;
}

	
void db_close(void)
{
	pthread_mutex_destroy(&dbLock);

	if (bubble_db)
	mysql_close(bubble_db);
}

void db_info(void)
{
	if (bubble_db)
	{
		int ret = mysql_query(bubble_db, "SELECT * FROM bubble_score");	 
		if (ret)
		{
			printf("mysql query failed!\n");
		}
		else
		{
			MYSQL_RES *result = mysql_store_result(bubble_db);
			if (result == NULL)
				printf("result failed\n");
			int num_fields = mysql_num_fields(result);
			MYSQL_ROW row;
			while ((row = mysql_fetch_row(result)))
			{
				for (int i = 0; i < num_fields; i++)
				{
					printf("%s ", row[i]?row[i]:"NULL");
				}
				printf("\n");
		
			}	
			mysql_free_result(result);
		}
	}
	mysql_close(bubble_db);
}

