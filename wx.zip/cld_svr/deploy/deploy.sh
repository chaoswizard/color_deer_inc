#!/bin/sh

mysql -ucldeer -pcldeer < db_init.sql

