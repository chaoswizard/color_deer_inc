#include <cxxtest/TestSuite.h>

#define __BUBBLE_TEST__
#include "net_pack.h"

class net_pack_test : public CxxTest::TestSuite
{
public: 
    void setUp()
    {
        g_is_big_endian = NET_IS_BIG_ENDIAN; 
    }
    
    void tearDown()
    {
    }
    
    void test_alignment_8bit()
    {
        // 8字节对齐
        TS_ASSERT(NET_ALIGNMENT_8BIT(7) == 8); 
        TS_ASSERT(NET_ALIGNMENT_8BIT(11) == 16); 
        TS_ASSERT(NET_ALIGNMENT_8BIT(234) == 240); 
        TS_ASSERT(NET_ALIGNMENT_8BIT(4505) == 4512); 
        TS_ASSERT(NET_ALIGNMENT_8BIT(3832) == 3832); 
    }
    
    void test_pack_init()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        TS_ASSERT(pack.header.len == NET_ALIGNMENT_8BIT(sizeof(net_pack_header))); 
        TS_ASSERT(pack.header.cmd == 0); 
        TS_ASSERT((void*)&pack == (void*)&pack.data[0]); 
    }
    
    void test_pack_alloc_block()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        void * next_ptr = &pack.data[pack.header.len]; 
        
        // 申请的空间是data上连续的空间，同时按8字节对齐
        unsigned int data_size = 78; 
        char * str_buf = (char*)net_pack_alloc_block(&pack, data_size); 
        TS_ASSERT(str_buf != NULL); 
        TS_ASSERT(str_buf == next_ptr); 
        //TS_ASSERT((long)str_buf == NET_ALIGNMENT_8BIT((long)str_buf)); 
        TS_ASSERT(pack.header.len == NET_ALIGNMENT_8BIT(data_size) + sizeof(net_pack_header)); 
    }
    
    void test_pack_alloc_block_data_len()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        
        char * str_buf = (char*)net_pack_alloc_block(&pack, 100); 
        TS_ASSERT(str_buf != NULL); 
        
        unsigned int remain_data_len = NET_PACK_SIZE - pack.header.len; 
        // 数据总长度超过数据包大小 
        str_buf = (char*)net_pack_alloc_block(&pack, remain_data_len + 1); 
        TS_ASSERT(str_buf == NULL); 
        // 大小刚刚好 
        str_buf = (char*)net_pack_alloc_block(&pack, remain_data_len); 
        TS_ASSERT(str_buf != NULL); 
        // 包已经满了
        str_buf = (char*)net_pack_alloc_block(&pack, 1); 
        TS_ASSERT(str_buf == NULL); 
    }
    
    void test_pack_put_int32()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        
        int * data_ptr = (int*)&pack.data[pack.header.len]; 
        int value = 3840; 
        int ret = net_pack_put_int32(&pack, value); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(*data_ptr == value); 
        
        // 模拟大端行为，放进去的值反转了
        g_is_big_endian = true; 
        
        net_pack_init(&pack, 0); 
        ret = net_pack_put_int32(&pack, value); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(*data_ptr == net_get_net_int32(value)); 
    }
    
    void test_pack_put_int64()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        
        long long * data_ptr = (long long*)&pack.data[pack.header.len]; 
        long long value = 3302443; 
        int ret = net_pack_put_int64(&pack, value); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(*data_ptr == value); 
        
        // 模拟大端行为，放进去的值反转了
        g_is_big_endian = true; 
        
        net_pack_init(&pack, 0); 
        ret = net_pack_put_int64(&pack, value); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(*data_ptr == net_get_net_int64(value)); 
    }
    
    void test_pack_put_string()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        
        char * data_ptr = &pack.data[pack.header.len]; 
        char * value = (char*)"hello, bubble"; 
        int ret = net_pack_put_string(&pack, value, strlen(value)); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(strcmp(data_ptr, value) == 0); 
    }
    
    void test_pack_get_org_offset()
    {
        TS_ASSERT(net_pack_get_org_offset() == sizeof(net_pack_header)); 
    }
    
    void test_pack_get_block()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        
        // 按顺序插入数据到数据包中 
        unsigned int data1_len = 239, data2_len = 33; 
        int * data_ptr1 = (int*)net_pack_alloc_block(&pack, data1_len); 
        TS_ASSERT(data_ptr1 != NULL); 
        long long * data_ptr2 = (long long*)net_pack_alloc_block(&pack, data2_len); 
        TS_ASSERT(data_ptr2 != NULL); 
        *data_ptr1 = 321; 
        *data_ptr2 = 0x3432; 
        
        // 按顺序读取数据包中数据 
        unsigned int offset = net_pack_get_org_offset(); 
        int * value_ptr1; 
        int ret = net_pack_get_block(&pack, offset, (void**)&value_ptr1, data1_len); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(data_ptr1 == value_ptr1); 
        TS_ASSERT(*value_ptr1 == 321); 
        
        long long * value_ptr2; 
        ret = net_pack_get_block(&pack, offset, (void**)&value_ptr2, data2_len); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(data_ptr2 == value_ptr2); 
        TS_ASSERT(*value_ptr2 == 0x3432); 
    }
    
    void test_pack_get_int32()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        
        // 正常读取放到数据包中的数据 
        int value = 984747; 
        int ret = net_pack_put_int32(&pack, value); 
        TS_ASSERT(ret == 0); 
        
        unsigned int offset = net_pack_get_org_offset(); 
        int value2; 
        ret = net_pack_get_int32(&pack, offset, (unsigned int*)&value2); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(value2 == value); 
        
        // 验证无论是否大小端取出的都是相同的数据 
        g_is_big_endian = !g_is_big_endian; 
        
        net_pack_init(&pack, 0); 
        ret = net_pack_put_int32(&pack, value); 
        TS_ASSERT(ret == 0); 
        
        offset = net_pack_get_org_offset(); 
        ret = net_pack_get_int32(&pack, offset, (unsigned int*)&value2); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(value2 == value); 
    }
    
    void test_pack_get_int64()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        
        // 正常读取放到数据包中的数据 
        long long value = 0x32FFAC; 
        int ret = net_pack_put_int64(&pack, value); 
        TS_ASSERT(ret == 0); 
        
        unsigned int offset = net_pack_get_org_offset(); 
        long long value2; 
        ret = net_pack_get_int64(&pack, offset, (unsigned long long*)&value2); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(value2 == value); 
        
        // 验证无论是否大小端取出的都是相同的数据 
        g_is_big_endian = !g_is_big_endian; 
        
        net_pack_init(&pack, 0); 
        ret = net_pack_put_int64(&pack, value); 
        TS_ASSERT(ret == 0); 
        
        offset = net_pack_get_org_offset(); 
        ret = net_pack_get_int64(&pack, offset, (unsigned long long*)&value2); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(value2 == value); 
    }
    
    void test_pack_get_string()
    {
        net_pack pack; 
        net_pack_init(&pack, 0); 
        
        char * value = (char*)"hello, bubble"; 
        int str_len = strlen(value); 
        int ret = net_pack_put_int32(&pack, str_len); 
        TS_ASSERT(ret == 0); 
        ret = net_pack_put_string(&pack, value, strlen(value)); 
        TS_ASSERT(ret == 0); 
        
        unsigned int offset = net_pack_get_org_offset(); 
        int value_len = 0; 
        char * value2 = (char*)""; 
        ret = net_pack_get_int32(&pack, offset, (unsigned int*)&value_len); 
        TS_ASSERT(ret == 0); 
        ret = net_pack_get_string(&pack, offset, &value2, value_len); 
        TS_ASSERT(ret == 0); 
        TS_ASSERT(strcmp(value, value2) == 0); 
    }
}; 

