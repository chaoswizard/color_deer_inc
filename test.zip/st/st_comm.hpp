#ifndef __ST_COMM_HPP__
#define __ST_COMM_HPP__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <netinet/tcp.h>
#include <time.h>
#include <fcntl.h>

#include "net_cmddef.h"
#include "net_pack.h"

#define TEST_SERVER_IP      "127.0.0.1"
#define TEST_SERVER_PORT    6666

inline void test_start_server(bool wait_ok)
{
    // ���������
    system("${BUBBLE_HOME}/bin/bbstart.sh 2>/dev/null"); 

    if (wait_ok)
    {
        // �ȴ�3����
        usleep(3000000); 
    }
}

inline void test_ignore_SIGPIPE()
{
    // ���ιܵ������źţ�����Զ������ر����ӣ�
    signal(SIGPIPE,SIG_IGN);
}

inline int test_connect(int & conn_fd)
{
    struct sockaddr_in pin;
    bzero(&pin, sizeof(pin));
    pin.sin_family = AF_INET;
    inet_pton(AF_INET, TEST_SERVER_IP, &pin.sin_addr);
    pin.sin_port = htons(TEST_SERVER_PORT);

    // ��¼����
    conn_fd = socket(AF_INET, SOCK_STREAM, 0);
    int ret = connect(conn_fd, (sockaddr*)&pin, sizeof(pin));
    if (ret < 0)
    {
        close(conn_fd); 
        return -1; 
    }
    
    // �������ݰ����Ϸ��� 
    int on = 1; 
    setsockopt(conn_fd, SOL_TCP, TCP_NODELAY, &on, sizeof (on));

    return 0; 
}

inline void test_disconnect(int conn_fd)
{
    close(conn_fd); 
}

inline int test_recv_pack(int conn_fd, net_pack * recv_pack)
{
    unsigned int read_len = read(conn_fd, recv_pack, sizeof(net_pack));
    if (read_len == 0) return -1; 
    return 0; 
}

inline int test_send_pack(int conn_fd, net_pack * send_pack)
{
    unsigned int pack_len = send_pack->header.len; 
    unsigned int write_len = write(conn_fd, send_pack, pack_len); 
    if (write_len == pack_len)
    {
        return 0; 
    }
    return -1; 
}

#endif // __ST_COMM_HPP__

